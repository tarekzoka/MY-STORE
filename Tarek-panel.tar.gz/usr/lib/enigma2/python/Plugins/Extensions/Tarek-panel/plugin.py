# -*- coding: utf-8 -*-
# =========================================================================
# Tarek-panel - Universal Auto-Scaling Edition (Vu+, Dreambox, 4K, FHD, HD)
# Compatible with: OpenATV, OpenPLi, Egami, BlackHole, OBH, VTi, DreamOS (OE2.5/2.6)
# Python 2.7 & Python 3.x (3.9 - 3.12) Universal Support
# =========================================================================
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console as ConsoleScreen
from Components.MenuList import MenuList
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Console import Console
import json
import os
import sys
import socket
import struct
import fcntl
import threading
import time
import re

try:
    from Screens.Standby import TryQuitMainloop
except ImportError:
    TryQuitMainloop = None

try:
    import enigma
except ImportError:
    enigma = None

try:
    from enigma import eTimer
except ImportError:
    eTimer = None

try:
    from enigma import gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, eListboxPythonMultiContent
    HAS_MULTICONTENT = True
except ImportError:
    gFont = None
    RT_HALIGN_LEFT = 0
    RT_HALIGN_RIGHT = 2
    eListboxPythonMultiContent = None
    HAS_MULTICONTENT = False

try:
    from Tools.LoadPixmap import loadPNG
except ImportError:
    loadPNG = None

try:
    from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
except ImportError:
    MultiContentEntryText = None
    MultiContentEntryPixmapAlphaTest = None

try:
    from enigma import RT_VALIGN_CENTER
except ImportError:
    RT_VALIGN_CENTER = 4

try:
    from Components.ProgressBar import ProgressBar
except ImportError:
    ProgressBar = None

try:
	from Tools.Directories import resolveFilename, SCOPE_PLUGINS
except ImportError:
	resolveFilename = None
	SCOPE_PLUGINS = None

# =========================================================================
# UNIVERSAL RESOLUTION DETECTION & AUTO-SCALING ENGINE
# =========================================================================
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

try:
    from enigma import getDesktop
    desk = getDesktop(0)
    if desk:
        d_size = desk.size()
        SCREEN_WIDTH = d_size.width()
        SCREEN_HEIGHT = d_size.height()
except Exception:
    pass

# Scale factors relative to FHD 1920x1080 base design
SCALE_X = float(SCREEN_WIDTH) / 1920.0
SCALE_Y = float(SCREEN_HEIGHT) / 1080.0

def scale_x(val):
    return int(round(val * SCALE_X))

def scale_y(val):
    return int(round(val * SCALE_Y))

def scale_font(size):
    return max(12, int(round(size * SCALE_Y)))

def scale_skin_layout(xml_layout):
    """
    Dynamically scales all skin attributes (position, size, font, itemHeight, borderWidth)
    to match the active receiver's desktop resolution (HD 720p, FHD 1080p, 4K UHD 2160p).
    """
    if abs(SCALE_X - 1.0) < 0.005 and abs(SCALE_Y - 1.0) < 0.005:
        return xml_layout

    def _sub_pos(m):
        px, py = int(m.group(1)), int(m.group(2))
        return 'position="%d,%d"' % (scale_x(px), scale_y(py))

    def _sub_size(m):
        sw, sh = int(m.group(1)), int(m.group(2))
        return 'size="%d,%d"' % (scale_x(sw), scale_y(sh))

    def _sub_font(m):
        fname, fsize = m.group(1), int(m.group(2))
        return 'font="%s;%d"' % (fname, scale_font(fsize))

    def _sub_item_height(m):
        ih = int(m.group(1))
        return 'itemHeight="%d"' % scale_y(ih)

    def _sub_border(m):
        bw = int(m.group(1))
        return 'borderWidth="%d"' % max(1, scale_x(bw))

    out = xml_layout
    out = re.sub(r'position="(\d+),(\d+)"', _sub_pos, out)
    out = re.sub(r'size="(\d+),(\d+)"', _sub_size, out)
    out = re.sub(r'font="([^;]+);(\d+)"', _sub_font, out)
    out = re.sub(r'itemHeight="(\d+)"', _sub_item_height, out)
    out = re.sub(r'borderWidth="(\d+)"', _sub_border, out)
    return out

VERSION_URL = "https://gitlab.com/hanfy1971/plugin/-/raw/main/MohamedStore-panel/version.json"
STORE_URL = "https://gitlab.com/hanfy1971/plugin/-/raw/main/MohamedStore-panel/feed/index.json"
UPDATE_SCRIPT_CMD = "wget -O - https://gitlab.com/hanfy1971/plugin/-/raw/main/MohamedStore-panel/install.sh | sh"
PLUGIN_VERSION = "1.3.2"

try:
    PLUGIN_DIR = os.path.dirname(__file__)
except NameError:
    PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel"

CACHE_FILE = os.path.join(PLUGIN_DIR, "store_cache.json")
ICON_FOLDER = os.path.join(PLUGIN_DIR, "images", "Icons")
FALLBACK_ICON_FOLDER = "/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/Icons"
PROGRESS_PNG_PATH = os.path.join(PLUGIN_DIR, "images", "progress.png")
FALLBACK_PROGRESS_PNG = "/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/progress.png"

def ensure_gradient_progress_png():
    """Generates an auto-scaled multi-color gradient progress bar PNG"""
    import zlib
    target_paths = [PROGRESS_PNG_PATH, FALLBACK_PROGRESS_PNG]
    for p in target_paths:
        try:
            if not os.path.exists(p):
                width = max(200, scale_x(436))
                height = max(8, scale_y(14))
                raw_data = bytearray()
                for y in range(height):
                    raw_data.append(0)  # Filter: None
                    for x in range(width):
                        t = float(x) / max(1.0, float(width - 1))
                        if t < 0.33:
                            st = t / 0.33
                            r = int(245 + (56 - 245) * st)
                            g = int(158 + (189 - 158) * st)
                            b = int(11 + (248 - 11) * st)
                        elif t < 0.66:
                            st = (t - 0.33) / 0.33
                            r = int(56 + (168 - 56) * st)
                            g = int(189 + (85 - 189) * st)
                            b = int(248 + (247 - 248) * st)
                        else:
                            st = (t - 0.66) / 0.34
                            r = int(168 + (236 - 168) * st)
                            g = int(85 + (72 - 85) * st)
                            b = int(247 + (153 - 247) * st)
                        raw_data.extend([max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))])

                png = bytearray(b'\x89PNG\r\n\x1a\n')
                ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
                png.extend(struct.pack('>I', 13) + b'IHDR' + ihdr + struct.pack('>I', zlib.crc32(b'IHDR' + ihdr) & 0xffffffff))
                compressed = zlib.compress(bytes(raw_data))
                png.extend(struct.pack('>I', len(compressed)) + b'IDAT' + compressed + struct.pack('>I', zlib.crc32(b'IDAT' + compressed) & 0xffffffff))
                png.extend(struct.pack('>I', 0) + b'IEND' + struct.pack('>I', zlib.crc32(b'IEND') & 0xffffffff))

                dirp = os.path.dirname(p)
                if not os.path.exists(dirp):
                    os.makedirs(dirp)
                with open(p, 'wb') as f:
                    f.write(png)
        except Exception:
            pass

try:
    ensure_gradient_progress_png()
except Exception:
    pass


# =========================================================================
# UNINSTALLER - Merged from Uninstaller Plugin by Lululla
# =========================================================================
uninstaller_version = '1.0'
uninstaller_myfile = '/tmp/ipkdb'


def uninstaller_delay():
	if os.path.exists(uninstaller_myfile):
		os.remove(uninstaller_myfile)
	try:
		if os.path.exists('/var/lib/dpkg/info'):
			cmd = "dpkg -l | grep ^ii | grep enigma2-plugin | awk '{print $2}' > " + uninstaller_myfile
		else:
			cmd = "opkg list-installed | grep enigma2-plugin > " + uninstaller_myfile
		os.system(cmd)
	except Exception:
		with open(uninstaller_myfile, 'w') as f:
			f.write('')


def uninstaller_build_list():
	if os.path.exists(uninstaller_myfile):
		os.remove(uninstaller_myfile)
	uninstaller_delay()
	os.system('sleep 2')
	if os.path.exists(uninstaller_myfile):
		with open(uninstaller_myfile) as file_:
			pkg_list = [line.strip() for line in file_ if line.strip()]
		if pkg_list:
			pkg_list.sort()
			return pkg_list
	return []


class UninstallerCheckList(MenuList):
	def __init__(self, list, enableWrapAround=True):
		MenuList.__init__(self, list, enableWrapAround)

class Uninstaller(Screen):
	skin = """
		<screen name="Uninstaller" position="center,center" size="1220,650" title="Uninstaller">
			<widget name="list" position="10,70" size="1200,510" scrollbarMode="showOnDemand" zPosition="2" font="Regular; 30" itemHeight="48" />
			<widget name="info" position="11,5" zPosition="4" size="1193,60" font="Regular; 38" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" />
			<widget name="key_red" position="10,592" size="290,48" font="Regular; 32" foregroundColor="#ffffff" backgroundColor="#e11d48" halign="center" valign="center" zPosition="5" />
			<widget name="key_green" position="310,592" size="290,48" font="Regular; 32" foregroundColor="#ffffff" backgroundColor="#059669" halign="center" valign="center" zPosition="5" />
			<widget name="key_yellow" position="610,592" size="290,48" font="Regular; 32" foregroundColor="#ffffff" backgroundColor="#d97706" halign="center" valign="center" zPosition="5" />
			<widget name="key_blue" position="910,592" size="290,48" font="Regular; 32" foregroundColor="#ffffff" backgroundColor="#0284c7" halign="center" valign="center" zPosition="5" />
		</screen>
		"""

	if SCREEN_WIDTH == 2560:
		skin = """
			<screen name="Uninstaller" position="center,center" size="1980,1200" title="Uninstaller">
				<widget name="list" position="30,160" size="1900,870" scrollbarMode="showOnDemand" zPosition="2" font="Regular; 52" itemHeight="78" />
				<widget name="info" position="11,5" zPosition="4" size="1937,140" font="Regular; 62" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" />
				<widget name="key_red" position="30,1040" size="460,72" font="Regular; 52" foregroundColor="#ffffff" backgroundColor="#e11d48" halign="center" valign="center" zPosition="5" />
				<widget name="key_green" position="510,1040" size="460,72" font="Regular; 52" foregroundColor="#ffffff" backgroundColor="#059669" halign="center" valign="center" zPosition="5" />
				<widget name="key_yellow" position="990,1040" size="460,72" font="Regular; 52" foregroundColor="#ffffff" backgroundColor="#d97706" halign="center" valign="center" zPosition="5" />
				<widget name="key_blue" position="1470,1040" size="460,72" font="Regular; 52" foregroundColor="#ffffff" backgroundColor="#0284c7" halign="center" valign="center" zPosition="5" />
			</screen>
			"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = Uninstaller.skin
		title = 'Uninstaller v.%s by Lululla' % uninstaller_version
		self.setTitle(title)
		self.pkg_list = []
		self.checked = []
		self['list'] = UninstallerCheckList([])
		self['info'] = Label()
		self['key_red'] = Label(_('Close'))
		self['key_green'] = Label(_('Delete Selected'))
		self['key_yellow'] = Label(_('Select All'))
		self['key_blue'] = Label(_('Deselect All'))
		self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {
			'ok': self.toggleCheck,
			'cancel': self.close,
			'red': self.close,
			'green': self.deleteSelected,
			'yellow': self.selectAll,
			'blue': self.deselectAll,
		}, -1)
		txt = _('Wait Please...')
		self['info'].setText(txt)
		self.timerw = eTimer()
		try:
			self.timerw_conn = self.timerw.timeout.connect(self.UploadList)
		except AttributeError:
			self.timerw.callback.append(self.UploadList)
		self.timerw.start(100, 1)

	def UploadList(self):
		if os.path.exists(uninstaller_myfile):
			os.remove(uninstaller_myfile)
		self.pkg_list = []
		self.checked = []
		uninstaller_delay()
		os.system('sleep 2')
		if os.path.exists(uninstaller_myfile):
			with open(uninstaller_myfile) as file_:
				for line in file_:
					pkg = line.strip()
					if pkg:
						self.pkg_list.append(pkg)
						self.checked.append(False)
		if len(self.pkg_list) > 0:
			self.pkg_list.sort()
			self.checked = [False] * len(self.pkg_list)
			self.refreshList()
			txt = _('Select packages to remove (OK=check, Green=delete)')
			self['info'].setText(txt)
		else:
			txt = _('No packages found!')
			self['info'].setText(txt)

	def refreshList(self):
		display_list = []
		for i, pkg in enumerate(self.pkg_list):
			if self.checked[i]:
				mark = '[X] '
			else:
				mark = '[ ] '
			display_list.append(mark + pkg)
		self['list'].setList(display_list)

	def toggleCheck(self):
		idx = self['list'].getSelectionIndex()
		if idx is not None and idx < len(self.checked):
			self.checked[idx] = not self.checked[idx]
			self.refreshList()

	def selectAll(self):
		self.checked = [True] * len(self.pkg_list)
		self.refreshList()

	def deselectAll(self):
		self.checked = [False] * len(self.pkg_list)
		self.refreshList()

	def deleteSelected(self):
		selected = [self.pkg_list[i] for i in range(len(self.pkg_list)) if self.checked[i]]
		if not selected:
			self.session.open(MessageBox, _('No packages selected!'), MessageBox.TYPE_INFO)
			return
		count = len(selected)
		msg = _('Are you sure you want to delete') + ' ' + str(count) + ' ' + _('packages?')
		self.session.openWithCallback(self.confirmDelete, MessageBox, msg, MessageBox.TYPE_YESNO)

	def confirmDelete(self, result):
		if not result:
			return
		selected = [self.pkg_list[i] for i in range(len(self.pkg_list)) if self.checked[i]]
		if not selected:
			return
		self.session.openWithCallback(self.chooseMethod, ChoiceBox, title=_('Select removal method:'), list=[(_('Remove'), 'rem'), (_('Force Remove'), 'force')])

	def chooseMethod(self, answer):
		if not answer or not answer[1]:
			return
		self.method = answer[1]
		selected = [self.pkg_list[i] for i in range(len(self.pkg_list)) if self.checked[i]]
		if not selected:
			return
		if self.method == 'force':
			if os.path.exists('/var/lib/dpkg/info'):
				cmd = 'dpkg -r --force-depends ' + ' '.join(selected)
			else:
				cmd = 'opkg remove --force-depends ' + ' '.join(selected)
		else:
			if os.path.exists('/var/lib/dpkg/info'):
				cmd = 'apt-get purge --auto-remove --assume-yes ' + ' '.join(selected)
			else:
				cmd = 'opkg remove ' + ' '.join(selected)
		txt = _('Removing') + ' ' + str(len(selected)) + ' ' + _('packages') + ' ...'
		self['info'].setText(txt)
		self.my_console = Console()
		self.my_console.ePopen(cmd + ' 2>&1', self.uninstall_done)

	def uninstall_done(self, result, retval, extra_args=None):
		try:
			txt = _('Removing done. Restarting GUI...')
			self['info'].setText(txt)
			self.timer_restart = eTimer()
			try:
				self.timer_restart_conn = self.timer_restart.timeout.connect(self.restartGui)
			except AttributeError:
				self.timer_restart.callback.append(self.restartGui)
			self.timer_restart.start(1500, 1)
		except Exception as e:
			print('uninstall_done error ', e)
			self.restartGui()

	def restartGui(self):
		try:
			if TryQuitMainloop:
				self.session.open(TryQuitMainloop, 3)
			elif enigma:
				enigma.quitMainloop(3)
			else:
				os.system('killall -9 enigma2')
		except Exception as e:
			print('restart error ', e)
			try:
				os.system('killall -9 enigma2')
			except Exception:
				pass

# =========================================================================
# OSCAM SMART TOGGLE / SWITCHER
# =========================================================================
def set_reader_blocks_state(content, is_enable_paid, is_enable_free):
    blocks = []
    current = []
    for line in content.split("\n"):
        if line.strip().startswith("[reader]"):
            if current:
                blocks.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        blocks.append(current)

    final_blocks = []
    for b in blocks:
        block_txt = "\n".join(b)
        if not block_txt.strip().startswith("[reader]"):
            final_blocks.append(block_txt)
            continue
            
        is_tiger = ("tigerhd4k" in block_txt.lower()) or ("free_tigerhd" in block_txt.lower())
        target_enable = 1 if (is_tiger and is_enable_free) or (not is_tiger and is_enable_paid) else 0
        
        new_lines = []
        has_enable = False
        for l in b:
            if l.strip().startswith("enable"):
                new_lines.append("enable                        = %d" % target_enable)
                has_enable = True
            else:
                new_lines.append(l)
        if not has_enable:
            new_lines.insert(1, "enable                        = %d" % target_enable)
            
        final_blocks.append("\n".join(new_lines))
        
    return "\n".join(final_blocks)

def generate_tigerhd_server():
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import urllib.parse as urllib_parse
            import ssl
            import http.cookiejar as cookiejar
            context = ssl._create_unverified_context()
        else:
            import urllib2
            import urllib as urllib_parse
            import ssl
            import cookielib as cookiejar
            try:
                context = ssl._create_unverified_context()
            except AttributeError:
                context = None

        main_oscam_path = "/etc/tuxbox/config/oscam.server"
        c_host, c_port, c_user, c_pass = "", "", "", ""
        clines = []

        try:
            cj = cookiejar.CookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            req = urllib2.Request('https://tigerhd4k.com/testoscam/', headers=headers)
            res = opener.open(req, timeout=8)
            page = res.read()
            if isinstance(page, bytes):
                page = page.decode('utf-8', 'ignore')

            token_m = re.search(r'name="_token"\s+value="([^"]+)"', page) or re.search(r"name='_token'\s+value='([^']+)'", page)
            trial_m = re.search(r'name="trial"\s+value="([^"]+)"', page) or re.search(r"name='trial'\s+value='([^']+)'", page)
            cs_m = re.search(r'name="CS"\s+value="([^"]+)"', page) or re.search(r"name='CS'\s+value='([^']+)'", page)

            if token_m and trial_m:
                post_fields = {
                    '_token': token_m.group(1),
                    'trial-ok': '1',
                    'trial': trial_m.group(1),
                    'CS': cs_m.group(1) if cs_m else "2021"
                }
                encoded_data = urllib_parse.urlencode(post_fields)
                if isinstance(encoded_data, str) and sys.version_info >= (3, 0):
                    encoded_data = encoded_data.encode('utf-8')

                post_headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                    'Referer': 'https://tigerhd4k.com/testoscam/',
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
                post_req = urllib2.Request('https://tigerhd4k.com/testoscam/', data=encoded_data, headers=post_headers)
                post_res = opener.open(post_req, timeout=10)
                post_html = post_res.read()
                if isinstance(post_html, bytes):
                    post_html = post_html.decode('utf-8', 'ignore')

                clines = re.findall(r'C:\s*[\w\.\-]+\s+\d+\s+[\w\.\-]+\s+[\w\.\-]+', post_html)
                if clines:
                    parts = clines[0].split()
                    if len(parts) >= 5:
                        c_host, c_port, c_user, c_pass = parts[1], parts[2], parts[3], parts[4]
        except Exception:
            pass

        if not c_host and not clines:
            try:
                update_url = "https://raw.githubusercontent.com/wwwgoper77-wq/epg-pro-licensing/main/oscam.server"
                fb_req = urllib2.Request(update_url, headers={'User-Agent': 'Mozilla/5.0'})
                fb_res = urllib2.urlopen(fb_req, timeout=6)
                fb_data = fb_res.read()
                if isinstance(fb_data, bytes):
                    fb_data = fb_data.decode('utf-8', 'ignore')
                
                clines_m = re.findall(r'C:\s*[\w\.\-]+\s+\d+\s+[\w\.\-]+\s+[\w\.\-]+', fb_data)
                if clines_m:
                    clines = clines_m
                    parts = clines[0].split()
                    c_host, c_port, c_user, c_pass = parts[1], parts[2], parts[3], parts[4]
            except Exception:
                pass

        if not c_host and not clines:
            return (False, "Could not obtain free server.")

        free_reader_block = (
            "### FREE_TIGERHD_START ###\n"
            "[reader]\n"
            "label                         = Store_CCcam_Daily\n"
            "enable                        = 1\n"
            "protocol                      = cccam\n"
            "device                        = %s,%s\n"
            "user                          = %s\n"
            "password                      = %s\n"
            "group                         = 1\n"
            "cccversion                    = 2.3.2\n"
            "ccckeepalive                  = 1\n"
            "### FREE_TIGERHD_END ###\n"
        ) % (c_host or "tigerhd4k.com", c_port or "37000", c_user or "1daytest", c_pass or "2021")

        all_oscam_paths = [
            "/etc/tuxbox/config/oscam.server",
            "/etc/tuxbox/config/oscam-emu/oscam.server",
            "/etc/tuxbox/config/oscam/oscam.server",
            "/etc/tuxbox/config/ncam.server"
        ]

        for op in all_oscam_paths:
            if op == main_oscam_path or os.path.exists(op):
                try:
                    existing_text = ""
                    if os.path.exists(op):
                        with open(op, "r") as rf:
                            existing_text = rf.read()
                    
                    if "### FREE_TIGERHD_START ###" in existing_text:
                        before = existing_text.split("### FREE_TIGERHD_START ###")[0]
                        after = existing_text.split("### FREE_TIGERHD_END ###")[-1]
                        existing_text = (before.rstrip() + "\n" + after.lstrip()).strip()
                    
                    if existing_text:
                        existing_text = set_reader_blocks_state(existing_text, is_enable_paid=False, is_enable_free=False)
                        final_content = existing_text + "\n\n" + free_reader_block
                    else:
                        final_content = free_reader_block
                    
                    with open(op, "w") as f:
                        f.write(final_content.strip() + "\n")
                except Exception:
                    pass

        os.system("killall -9 oscam oscam_svn oscam-oe2.0 oscam-emu ncam ncam.arm gcam 2>/dev/null; sleep 1; oscam -b 2>/dev/null || oscam & 2>/dev/null; /etc/init.d/softcam restart 2>/dev/null")

        res_msg = "Store Daily CCcam Activated Successfully!\n\n"
        res_msg += "Description: Server opening most world packages\n\n"
        res_msg += "Status:\n- Store Server (Store CCcam): ACTIVE (ON)\n- Paid Server: PAUSED (OFF)\n\nOSCam restarted automatically."
        return (True, res_msg)
    except Exception as e:
        return (False, "Error: " + str(e))

def restore_paid_oscam():
    all_oscam_paths = [
        "/etc/tuxbox/config/oscam.server",
        "/etc/tuxbox/config/oscam-emu/oscam.server",
        "/etc/tuxbox/config/oscam/oscam.server",
        "/etc/tuxbox/config/ncam.server"
    ]
    try:
        for op in all_oscam_paths:
            if os.path.exists(op):
                with open(op, "r") as f:
                    content = f.read()
                
                if "### FREE_TIGERHD_START ###" in content:
                    before = content.split("### FREE_TIGERHD_START ###")[0]
                    after = content.split("### FREE_TIGERHD_END ###")[-1]
                    content = (before.rstrip() + "\n" + after.lstrip()).strip()
                elif "tigerhd4k" in content or "Store_CCcam_Daily" in content:
                    lines = []
                    skip = False
                    for line in content.split("\n"):
                        if line.strip().startswith("[reader]"):
                            skip = False
                        if "tigerhd4k" in line or "Store_CCcam_Daily" in line:
                            skip = True
                        if not skip:
                            lines.append(line)
                    content = "\n".join(lines).strip()
                
                new_content = set_reader_blocks_state(content, is_enable_paid=True, is_enable_free=False)
                with open(op, "w") as f:
                    f.write(new_content.strip() + "\n")

        os.system("killall -9 oscam oscam_svn oscam-oe2.0 oscam-emu ncam ncam.arm gcam 2>/dev/null; sleep 1; oscam -b 2>/dev/null || oscam & 2>/dev/null; /etc/init.d/softcam restart 2>/dev/null")
        
        msg = "Paid Server Restored Successfully!\n\nStatus:\n- Paid Server: ACTIVE (ON)\n- Store Free Server: DISABLED (OFF)\n\nOSCam restarted automatically."
        return (True, msg)
    except Exception as e:
        return (False, "Error: " + str(e))

def get_active_oscam_status():
    all_oscam_paths = [
        "/etc/tuxbox/config/oscam.server",
        "/etc/tuxbox/config/oscam-emu/oscam.server",
        "/etc/tuxbox/config/oscam/oscam.server",
        "/etc/tuxbox/config/ncam.server"
    ]
    found_path = None
    content = ""
    for path in all_oscam_paths:
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    content = f.read().strip()
                if content:
                    found_path = path
                    break
            except Exception:
                pass

    if not found_path or not content:
        return (False, u"[!] \u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0645\u0644\u0641 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0633\u064a\u0631\u0641\u0631!\nFile /etc/tuxbox/config/oscam.server not found or empty.")

    try:
        blocks = []
        current = []
        for line in content.split("\n"):
            if line.strip().startswith("[reader]"):
                if current:
                    blocks.append("\n".join(current))
                current = [line]
            else:
                current.append(line)
        if current:
            blocks.append("\n".join(current))

        active_readers = []

        for b in blocks:
            if not b.strip().startswith("[reader]"):
                continue
            
            lbl_match = re.search(r'label\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            raw_label = lbl_match.group(1).strip() if lbl_match else "Reader"

            dev_match = re.search(r'device\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            dev_val = dev_match.group(1).strip() if dev_match else "N/A"

            proto_match = re.search(r'protocol\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            proto_val = proto_match.group(1).strip() if proto_match else "cccam"

            low_lbl = raw_label.lower()
            low_proto = proto_val.lower()
            low_dev = dev_val.lower()
            if low_proto in ["emu", "ecmbin", "constcw", "internal", "softcam"] or \
               low_lbl in ["emulator", "ecmemu", "streamrelay", "icam", "softcam"] or \
               low_dev in ["emulator", "ecmemu"] or \
               "emu" in low_proto or "emu" in low_lbl or "ecm" in low_proto or "ecm" in low_lbl:
                continue

            en_match = re.search(r'enable\s*=\s*(\d+)', b, re.IGNORECASE)
            is_enabled = (en_match.group(1).strip() != "0") if en_match else True
            
            if not is_enabled:
                continue

            is_store_server = ("tigerhd" in b.lower()) or ("free_tigerhd" in b.lower()) or ("store" in b.lower()) or ("store" in raw_label.lower())
            
            user_match = re.search(r'user\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            user_val = user_match.group(1).strip() if user_match else "N/A"

            grp_match = re.search(r'group\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            grp_val = grp_match.group(1).strip() if grp_match else "1"

            ccc_ver_match = re.search(r'cccversion\s*=\s*([^\n\r]+)', b, re.IGNORECASE)
            ccc_ver = ccc_ver_match.group(1).strip() if ccc_ver_match else ""

            if is_store_server:
                label_val = u"\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062a\u062c\u0631 (Store Server)"
                server_type = u"\u0633\u064a\u0631\u0641\u0631 \u0633\u064a\u0633\u0643\u0627\u0645 \u0627\u0644\u0645\u062a\u062c\u0631 \u0627\u0644\u064a\u0648\u0645\u064a"
                card_info = [
                    u"[+] \u0627\u0644\u0646\u0648\u0639: %s" % server_type,
                    u"[+] \u0627\u0644\u0625\u0633\u0645 (Label): %s" % label_val,
                    u"[+] \u0627\u0644\u0648\u0635\u0641: \u0633\u064a\u0631\u0641\u0631 \u0641\u0627\u062a\u062d \u0627\u063a\u0644\u0628 \u0627\u0644\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0639\u0627\u0644\u0645\u064a\u0629",
                    u"[+] \u0627\u0644\u062d\u0627\u0644\u0629: [ACTIVE - ON] \u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062a\u062c\u0631 \u0634\u063a\u0627\u0644 \u0648\u0646\u0634\u0637"
                ]
            else:
                label_val = raw_label
                server_type = u"\u0633\u064a\u0631\u0641\u0631 \u0645\u062f\u0641\u0648\u0639 / \u062e\u0627\u0635 (Paid/Custom)"
                card_info = [
                    u"[+] \u0627\u0644\u0646\u0648\u0639: %s" % server_type,
                    u"[+] \u0627\u0644\u0625\u0633\u0645 (Label): %s" % label_val,
                    u"[+] \u0627\u0644\u0628\u0631\u0648\u062a\u0648\u0643\u0648\u0644: %s %s" % (proto_val, ("(v%s)" % ccc_ver) if ccc_ver else ""),
                    u"[+] \u0627\u0644\u0639\u0646\u0648\u0627\u0646 (Host/Port): %s" % dev_val,
                    u"[+] \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 (User): %s" % user_val,
                    u"[+] \u0627\u0644\u0645\u062c\u0645\u0648\u0639\u0629 (Group): %s" % grp_val,
                    u"[+] \u0627\u0644\u062d\u0627\u0644\u0629: [ACTIVE - ON] \u0634\u063a\u0627\u0644 \u0648\u0646\u0634\u0637"
                ]
            
            active_readers.append("\n".join(card_info))

        if not active_readers:
            msg = (
                u"[!] \u0644\u0627 \u064a\u0648\u062c\u062f \u0623\u064a \u0633\u064a\u0631\u0641\u0631 \u0646\u0634\u0637 \u062d\u0627\u0644\u064a\u0627\u064b!\n"
                "----------------------------------------\n"
                u"[-] \u062c\u0645\u064a\u0639 \u0627\u0644\u0633\u064a\u0631\u0641\u0631\u0627\u062a \u0641\u064a oscam.server \u0645\u0639\u0637\u0644\u0629 (enable = 0) \u0623\u0648 \u063a\u064a\u0631 \u0645\u0636\u0627\u0641\u0629.\n\n"
                u"[+] \u0644\u062a\u0634\u063a\u064a\u0644 \u0633\u064a\u0631\u0641\u0631:\n"
                u"- \u064a\u0645\u0643\u0646\u0643 \u0627\u062e\u062a\u064a\u0627\u0631 '\u0633\u064a\u0631\u0641\u0631 \u0633\u064a\u0633\u0643\u0627\u0645 \u0627\u0644\u0645\u062a\u062c\u0631 \u0627\u0644\u064a\u0648\u0645\u064a'\n"
                u"- \u0623\u0648 \u0627\u062e\u062a\u064a\u0627\u0631 '\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0627\u0644\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062f\u0641\u0648\u0639'"
            )
            return (True, msg)

        emu_running = False
        try:
            p_check = os.popen("pgrep -x oscam || pgrep -x oscam-emu || pgrep -x ncam || pidof oscam").read().strip()
            if p_check:
                emu_running = True
        except Exception:
            pass

        msg = u"[*] \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0646\u0634\u0637 (\u0627\u0644\u0634\u063a\u0627\u0644 \u062d\u0627\u0644\u064a\u0627\u064b):\n"
        msg += "========================================\n"
        if emu_running:
            msg += u"[*] \u062d\u0627\u0644\u0629 \u0627\u0644\u0625\u064a\u0645\u0648: \u0634\u063a\u0627\u0644 \u0641\u064a \u0627\u0644\u062e\u0644\u0641\u064a\u0629 (OSCam Running)\n"
        msg += "[*] Path: %s\n" % found_path
        msg += "========================================\n\n"
        msg += "\n\n----------------------------------------\n\n".join(active_readers)

        return (True, msg)
    except Exception as e:
        return (False, u"\u062d\u062f\u062b \u062e\u0637\u0623 \u0623\u062b\u0646\u0627\u0621 \u0641\u062d\u0635 \u0627\u0644\u0633\u064a\u0631\u0641\u0631: " + str(e))

def restart_oscam_service():
    try:
        os.system("killall -9 oscam oscam_svn oscam-oe2.0 oscam-emu ncam ncam.arm gcam 2>/dev/null; sleep 1; oscam -b 2>/dev/null || oscam & 2>/dev/null; /etc/init.d/softcam restart 2>/dev/null")
        return (True, "OSCam / SoftCam restarted successfully!")
    except Exception as e:
        return (False, "Restart error: " + str(e))

def stop_oscam_service():
    try:
        os.system("killall -9 oscam oscam_svn oscam-oe2.0 oscam-emu ncam ncam.arm gcam 2>/dev/null")
        return (True, "OSCam / SoftCam stopped successfully!")
    except Exception as e:
        return (False, "Stop error: " + str(e))

BUILTIN_SYSTEM_TOOLS = [
    {
        "name": u"\u0639\u0631\u0636 \u062d\u0627\u0644\u0629 \u0627\u0644\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0646\u0634\u0637 (Check OSCam Status)",
        "type": "tool",
        "action": "check_oscam_status",
        "description": u"\u0641\u062d\u0635 \u0645\u0644\u0641 oscam.server \u0648\u0639\u0631\u0636 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062a\u062c\u0631 \u0627\u0644\u0634\u063a\u0627\u0644 \u0641\u0642\u0637 (Active Only)."
    },
    {
        "name": u"\u0633\u064a\u0633\u0643\u0627\u0645 \u0627\u0644\u0645\u062a\u062c\u0631 \u0627\u0644\u064a\u0648\u0645\u064a (Store Daily CCcam Server)",
        "type": "tool",
        "action": "tiger_server",
        "description": u"\u0633\u064a\u0631\u0641\u0631 \u0641\u0627\u062a\u062d \u0627\u063a\u0644\u0628 \u0627\u0644\u0628\u0627\u0642\u0627\u062a \u0627\u0644\u0639\u0627\u0644\u0645\u064a\u0629"
    },
    {
        "name": u"\u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0627\u0644\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062f\u0641\u0648\u0639 (Restore Paid OSCam)",
        "type": "tool",
        "action": "restore_paid",
        "description": u"\u0625\u0639\u0627\u062f\u0629 \u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062f\u0641\u0648\u0639 \u0627\u0644\u0623\u0635\u0644\u064a \u0648\u0625\u064a\u0642\u0627\u0641 \u0633\u064a\u0631\u0641\u0631 \u0627\u0644\u0645\u062a\u062c\u0631."
    },
    {
        "name": u"\u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0625\u064a\u0645\u0648 OSCam (Restart OSCam)",
        "type": "tool",
        "action": "restart_oscam",
        "description": u"\u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0625\u064a\u0645\u0648 OSCam / NCam \u0644\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0634\u0641\u0631\u0627\u062a."
    },
    {
        "name": u"\u0625\u064a\u0642\u0627\u0641 \u0625\u064a\u0645\u0648 OSCam (Stop OSCam)",
        "type": "tool",
        "action": "stop_oscam",
        "description": u"\u0625\u064a\u0642\u0627\u0641 \u062a\u0634\u063a\u064a\u0644 \u0625\u064a\u0645\u0648 OSCam / NCam."
    },
    {
        "name": u"\u062d\u0630\u0641 \u0627\u0644\u0628\u0644\u062c\u0646\u0627\u062a \u0648\u0627\u0644\u0633\u0643\u064a\u0646\u0627\u062a (Uninstaller)",
        "type": "tool",
        "action": "uninstaller",
        "description": u"\u062d\u0630\u0641 \u0627\u0644\u0628\u0644\u0627\u062c\u0646\u0627\u062a \u0648\u0627\u0644\u0633\u0643\u064a\u0646\u0627\u062a \u0627\u0644\u0645\u062b\u0628\u062a\u0629 \u062d\u064a\u062b \u064a\u0645\u0643\u0646\u0643 \u0627\u062e\u062a\u064a\u0627\u0631 \u0648\u062d\u0630\u0641 \u0623\u064a \u0625\u0636\u0627\u0641\u0629 (\u062d\u0630\u0641 \u0639\u0627\u062f\u064a \u0623\u0648 \u0625\u062c\u0628\u0627\u0631\u064a)"
    },

    {
        "name": u"\u26bd \u0645\u0628\u0627\u0631\u064a\u0627\u062a \u0627\u0644\u064a\u0648\u0645 \u0648\u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0646\u0627\u0642\u0644\u0629 (Football on TV)",
        "type": "tool",
        "action": "football_matches",
        "description": u"\u0639\u0631\u0636 \u0645\u0628\u0627\u0631\u064a\u0627\u062a \u0643\u0631\u0629 \u0627\u0644\u0642\u062f\u0645 \u0627\u0644\u064a\u0648\u0645 \u0648\u063a\u062f\u0627\u064b \u0648\u0628\u0639\u062f \u063a\u062f \u0645\u0639 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0646\u0627\u0642\u0644\u0629 (\u0627\u0644\u0645\u0635\u062f\u0631: liveonsat.com)"
    },

    {
        "name": u"\U0001F324 \u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0642\u0633 (Weather)",
        "type": "tool",
        "action": "weather",
        "description": u"\u0639\u0631\u0636 \u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0642\u0633 \u0627\u0644\u062d\u0627\u0644\u064a\u0629 \u0648\u062a\u0648\u0642\u0639\u0627\u062a 5 \u0623\u064a\u0627\u0645 \u0644\u0623\u064a \u0645\u062f\u064a\u0646\u0629 \u0641\u064a \u0627\u0644\u0639\u0627\u0644\u0645 \u0645\u0639 \u0627\u0644\u0628\u062d\u062b (\u0627\u0644\u0645\u0635\u062f\u0631: open-meteo)"
    },
    {
        "name": u"\U0001F4FA \u0642\u0646\u0648\u0627\u062a IPTV \u0645\u062c\u0627\u0646\u064a\u0629 (IPTV)",
        "type": "tool",
        "action": "iptv",
        "description": u"\u0642\u0648\u0627\u0626\u0645 \u0642\u0646\u0648\u0627\u062a IPTV \u0645\u062c\u0627\u0646\u064a\u0629 \u062d\u0633\u0628 \u0627\u0644\u062f\u0648\u0644\u0629 \u0645\u0639 \u0625\u0645\u0643\u0627\u0646\u064a\u0629 \u0627\u0644\u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 (\u0627\u0644\u0645\u0635\u062f\u0631: iptv-org)"
    },
    {
        "name": u"\U0001F4E1 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0648\u0627\u0644\u0623\u0642\u0645\u0627\u0631 (Frequencies)",
        "type": "tool",
        "action": "kingofsat",
        "description": u"\u0639\u0631\u0636 \u062a\u0631\u062f\u062f\u0627\u062a \u0648\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0623\u0642\u0645\u0627\u0631 \u0627\u0644\u0635\u0646\u0627\u0639\u064a\u0629 (\u0646\u0627\u064a\u0644 \u0633\u0627\u062a\u060c \u0639\u0631\u0628 \u0633\u0627\u062a\u060c \u0625\u0633 \u0647\u0627\u064a\u0644...) (\u0627\u0644\u0645\u0635\u062f\u0631: KingOfSat)"
    },

    {
        "name": u"\u062a\u0646\u0638\u064a\u0641 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0648\u0627\u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0645\u0624\u0642\u062a\u0629",
        "type": "tool",
        "cmd": "rm -rf /tmp/*.ipk /tmp/*.tar.gz /tmp/*.zip /var/volatile/tmp/*",
        "description": u"\u062d\u0630\u0641 \u062c\u0645\u064a\u0639 \u0645\u0644\u0641\u0627\u062a \u0627\u0644\u062a\u062b\u0628\u064a\u062a \u0648\u0627\u0644\u0645\u0644\u0641\u0627\u062a \u0627\u0644\u0645\u0624\u0642\u062a\u0629 \u0645\u0646 /tmp."
    },
    {
        "name": u"\u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0648\u0627\u062c\u0647\u0629 (Restart GUI)",
        "type": "tool",
        "cmd": "restart_gui",
        "description": u"\u0625\u0639\u0627\u062f\u0629 \u062a\u0634\u063a\u064a\u0644 \u0648\u0627\u062c\u0647\u0629 \u0627\u0644\u0633\u0633\u062a\u0645."
    }
]

def get_neoboot_images_upload_path():
    for p in ["/media/hdd/ImagesUpload", "/media/usb/ImagesUpload", "/media/mmc/ImagesUpload", "/data/ImagesUpload", "/media/hdd", "/media/usb"]:
        if os.path.exists(p):
            return p
    return "/media/hdd/ImagesUpload"

def get_direct_hdd_root_path():
    for drive in ["/media/hdd", "/media/usb", "/media/mmc", "/data"]:
        if os.path.exists(drive):
            return drive
    return "/media/hdd"

def get_real_box_ip():
    for ifname in ["eth0", "wlan0", "eth1", "ra0", "wlan1", "lan0", "enp3s0"]:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            ifname_bytes = ifname.encode('utf-8') if sys.version_info >= (3, 0) else ifname
            ip = socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname_bytes[:15]))[20:24])
            s.close()
            if ip and not ip.startswith("127."):
                return ip
        except Exception:
            pass
    return "192.168.1.1"

def get_category_icon_path(category_id):
    try:
        cat_lower = str(category_id).lower().replace("_", "").replace(" ", "")
        if "plugin" in cat_lower:
            filename = "plugins.png"
        elif "skin" in cat_lower:
            filename = "skins.png"
        elif "tool" in cat_lower:
            filename = "tools.png"
        elif "image" in cat_lower or "system" in cat_lower:
            filename = "system_images.png"
        elif "picon" in cat_lower:
            filename = "picons.png"
        elif "channel" in cat_lower or "setting" in cat_lower:
            filename = "channels.png"
        elif "softcam" in cat_lower or "cam" in cat_lower or "emu" in cat_lower:
            filename = "softcam.png"
        elif "noval" in cat_lower or "nofla" in cat_lower:
            filename = "novaler.png"
        else:
            filename = None
            
        if filename:
            for folder in [ICON_FOLDER, FALLBACK_ICON_FOLDER, os.path.join(PLUGIN_DIR, "images")]:
                try:
                    full_p = os.path.join(folder, filename)
                    if os.path.exists(full_p):
                        return full_p
                except Exception:
                    pass
    except Exception:
        pass
    return None

def get_item_icon_path(item, category_id):
    try:
        if not isinstance(item, dict):
            return get_category_icon_path(category_id)

        for key in ("icon", "image", "thumbnail"):
            val = item.get(key)
            if val and isinstance(val, (str, getattr(sys, 'unicode', str))):
                val = val.strip()
                try:
                    if os.path.isabs(val) and os.path.exists(val):
                        return val
                except Exception:
                    pass
                for folder in [ICON_FOLDER, FALLBACK_ICON_FOLDER, os.path.join(PLUGIN_DIR, "images")]:
                    try:
                        p = os.path.join(folder, val)
                        if os.path.exists(p):
                            return p
                    except Exception:
                        pass

        item_id = item.get("id") or item.get("name") or ""
        if item_id:
            clean_name = str(item_id).lower().replace(" ", "_").replace("-", "_") + ".png"
            for folder in [ICON_FOLDER, FALLBACK_ICON_FOLDER, os.path.join(PLUGIN_DIR, "images")]:
                try:
                    p = os.path.join(folder, clean_name)
                    if os.path.exists(p):
                        return p
                except Exception:
                    pass

        if "items" in item and isinstance(item["items"], list):
            for folder_icon in ("folder.png", "subfolder.png"):
                try:
                    p = os.path.join(ICON_FOLDER, folder_icon)
                    if os.path.exists(p):
                        return p
                except Exception:
                    pass

        if item.get("type") == "tool":
            try:
                p = os.path.join(ICON_FOLDER, "tools.png")
                if os.path.exists(p):
                    return p
            except Exception:
                pass

        return get_category_icon_path(category_id)
    except Exception:
        return None

def count_items_recursive(items_list):
    if not isinstance(items_list, list):
        return 0
    count = 0
    for it in items_list:
        if isinstance(it, dict) and "items" in it and isinstance(it["items"], list):
            count += count_items_recursive(it["items"])
        else:
            count += 1
    return count

def load_json_network(url):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
            context = ssl._create_unverified_context()
        else:
            import urllib2
            import ssl
            try:
                context = ssl._create_unverified_context()
            except AttributeError:
                context = None
        
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        if context:
            response = urllib2.urlopen(req, timeout=5, context=context)
        else:
            response = urllib2.urlopen(req, timeout=5)
        data = response.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        return json.loads(data)
    except Exception:
        return None

# Base Full HD reference XML layout
RAW_SKIN_LAYOUT = """
<screen name="Tarek-panel" position="center,center" size="1724,920" title="Tarek-panel" flags="wfNoBorder">
    <eLabel position="0,0" size="1724,920" backgroundColor="#05070c" zPosition="-11" />
    <ePixmap position="0,0" size="1724,920" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/background.png" zPosition="-10" transparent="0" alphatest="off" />

    <!-- HEADER PANEL -->
    <eLabel position="20,15" size="1684,84" backgroundColor="#0f111a" zPosition="-1" />
    <eLabel position="20,15" size="1684,2" backgroundColor="#be185d" zPosition="0" />
    <eLabel position="20,15" size="4,84" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="1700,15" size="4,84" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="20,99" size="1684,2" backgroundColor="#e11d48" />
    
    <ePixmap position="32,24" size="190,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/logo.png" zPosition="2" scale="1" transparent="1" alphatest="blend" />
    <eLabel position="230,22" size="120,30" text="Tarek-panel" font="Regular;24" foregroundColor="#f59e0b" backgroundColor="#0f111a" transparent="1" />
    <eLabel position="350,22" size="90,30" text="STORE" font="Regular;24" foregroundColor="#38bdf8" backgroundColor="#0f111a" transparent="1" />
    <eLabel position="230,50" size="70,2" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="300,50" size="70,2" backgroundColor="#38bdf8" zPosition="2" />
    <eLabel position="370,50" size="70,2" backgroundColor="#ec4899" zPosition="2" />
    <eLabel position="230,56" size="75,22" text=" v1.3.2 " font="Regular;17" foregroundColor="#ffffff" backgroundColor="#be185d" transparent="0" halign="center" />

    <!-- HARDWARE CHIPS -->
    <eLabel position="445,19" size="305,74" backgroundColor="#070913" zPosition="1" />
    <eLabel position="445,19" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <eLabel position="445,19" size="3,74" backgroundColor="#60a5fa" zPosition="2" />
    <eLabel position="445,91" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <widget name="sys_device" position="455,23" size="290,32" font="Regular;24" foregroundColor="#60a5fa" backgroundColor="#070913" transparent="1" zPosition="3" />
    <widget name="sys_image" position="455,56" size="290,30" font="Regular;22" foregroundColor="#c084fc" backgroundColor="#070913" transparent="1" zPosition="3" />

    <eLabel position="760,19" size="300,74" backgroundColor="#070913" zPosition="1" />
    <eLabel position="760,19" size="300,2" backgroundColor="#be185d" zPosition="2" />
    <eLabel position="760,19" size="3,74" backgroundColor="#f43f5e" zPosition="2" />
    <eLabel position="760,91" size="300,2" backgroundColor="#be185d" zPosition="2" />
    <widget name="sys_cpu" position="770,23" size="285,32" font="Regular;24" foregroundColor="#f43f5e" backgroundColor="#070913" transparent="1" zPosition="3" />
    <widget name="sys_temp" position="770,56" size="285,30" font="Regular;22" foregroundColor="#fb923c" backgroundColor="#070913" transparent="1" zPosition="3" />

    <eLabel position="1070,19" size="305,74" backgroundColor="#070913" zPosition="1" />
    <eLabel position="1070,19" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <eLabel position="1070,19" size="3,74" backgroundColor="#34d399" zPosition="2" />
    <eLabel position="1070,91" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <widget name="sys_ram" position="1080,23" size="290,32" font="Regular;24" foregroundColor="#34d399" backgroundColor="#070913" transparent="1" zPosition="3" />
    <widget name="sys_flash" position="1080,56" size="290,30" font="Regular;22" foregroundColor="#a7f3d0" backgroundColor="#070913" transparent="1" zPosition="3" />

    <eLabel position="1385,19" size="305,74" backgroundColor="#070913" zPosition="1" />
    <eLabel position="1385,19" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <eLabel position="1385,19" size="3,74" backgroundColor="#38bdf8" zPosition="2" />
    <eLabel position="1385,91" size="305,2" backgroundColor="#be185d" zPosition="2" />
    <widget name="sys_ip" position="1395,23" size="290,32" font="Regular;24" foregroundColor="#38bdf8" backgroundColor="#070913" transparent="1" zPosition="3" />
    <widget name="sys_net" position="1395,56" size="290,30" font="Regular;22" foregroundColor="#818cf8" backgroundColor="#070913" transparent="1" zPosition="3" />

    <!-- LEFT PANEL: CATEGORIES -->
    <eLabel position="20,112" size="380,688" backgroundColor="#0f111a" zPosition="-1" />
    <eLabel position="20,112" size="380,2" backgroundColor="#be185d" zPosition="0" />
    <eLabel position="20,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="396,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="32,126" size="356,35" text="CATEGORIES" font="Regular;30" foregroundColor="#f43f5e" backgroundColor="#0f111a" transparent="1" />
    <eLabel position="32,166" size="356,2" backgroundColor="#be185d" />
    <widget name="categories_list" position="25,176" size="370,616" itemHeight="80" scrollbarMode="showOnDemand" foregroundColor="#f3f4f6" backgroundColor="#0f111a" transparent="1" />

    <!-- CENTER PANEL: PACKAGES -->
    <eLabel position="412,112" size="780,688" backgroundColor="#0f111a" zPosition="-1" />
    <eLabel position="412,112" size="780,2" backgroundColor="#be185d" zPosition="0" />
    <eLabel position="412,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="1188,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="428,126" size="748,35" text="AVAILABLE PACKAGES" font="Regular;30" foregroundColor="#f43f5e" backgroundColor="#0f111a" transparent="1" />
    <eLabel position="428,166" size="748,2" backgroundColor="#be185d" />
    <widget name="items_list" position="417,176" size="768,616" itemHeight="76" scrollbarMode="showOnDemand" foregroundColor="#f3f4f6" backgroundColor="#0f111a" transparent="1" />

    <!-- RIGHT PANEL: DETAILS & FACEBOOK & PROGRESS -->
    <eLabel position="1204,112" size="500,688" backgroundColor="#0f111a" zPosition="-1" />
    <eLabel position="1204,112" size="500,2" backgroundColor="#be185d" zPosition="0" />
    <eLabel position="1204,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="1700,112" size="4,688" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="1222,126" size="464,35" text="INFORMATION" font="Regular;30" foregroundColor="#f43f5e" backgroundColor="#0f111a" transparent="1" />
    <eLabel position="1222,166" size="464,2" backgroundColor="#be185d" />
    
    <widget name="description" position="1222,174" size="464,376" font="Regular;24" foregroundColor="#e2e8f0" backgroundColor="#0f111a" transparent="1" valign="top" />

    <!-- FACEBOOK & BARCODE BOX -->
    <eLabel position="1220,558" size="468,110" backgroundColor="#120e1a" zPosition="1" />
    <eLabel position="1220,558" size="468,2" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="1220,558" size="2,110" backgroundColor="#0284c7" zPosition="2" />
    <eLabel position="1686,558" size="2,110" backgroundColor="#ec4899" zPosition="2" />
    <eLabel position="1220,666" size="468,2" backgroundColor="#f59e0b" zPosition="2" />
    
    <ePixmap position="1230,571" size="78,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/avatar.png" zPosition="3" scale="1" transparent="1" alphatest="blend" />
    <ePixmap position="1316,571" size="82,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/qrcode.png" zPosition="3" scale="1" transparent="1" alphatest="blend" />
    
    <eLabel position="1408,568" size="90,34" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="1498,568" size="90,34" backgroundColor="#0284c7" zPosition="2" />
    <eLabel position="1588,568" size="90,34" backgroundColor="#be185d" zPosition="2" />
    <eLabel position="1410,570" size="266,30" backgroundColor="#1a1426" zPosition="3" />
    <widget name="facebook_title" position="1408,568" size="260,34" font="Regular;24" foregroundColor="#fde047" backgroundColor="#1a1426" transparent="1" zPosition="4" halign="right" />
    <widget name="facebook_label" position="1408,608" size="270,46" text="https://www.facebook.com/share/1G8inRhUib/" font="Regular;18" foregroundColor="#38bdf8" backgroundColor="#120e1a" transparent="1" zPosition="3" halign="right" />

    <!-- PROGRESS BOX WITH MULTI-COLOR ACCENTS -->
    <eLabel position="1220,676" size="468,114" backgroundColor="#0c0714" zPosition="1" />
    <eLabel position="1220,676" size="117,2" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="1337,676" size="117,2" backgroundColor="#0284c7" zPosition="2" />
    <eLabel position="1454,676" size="117,2" backgroundColor="#a855f7" zPosition="2" />
    <eLabel position="1571,676" size="117,2" backgroundColor="#ec4899" zPosition="2" />
    <eLabel position="1220,676" size="2,114" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="1686,676" size="2,114" backgroundColor="#ec4899" zPosition="2" />
    <eLabel position="1220,788" size="117,2" backgroundColor="#f59e0b" zPosition="2" />
    <eLabel position="1337,788" size="117,2" backgroundColor="#0284c7" zPosition="2" />
    <eLabel position="1454,788" size="117,2" backgroundColor="#a855f7" zPosition="2" />
    <eLabel position="1571,788" size="117,2" backgroundColor="#ec4899" zPosition="2" />
    
    <widget name="progress" position="1236,686" size="436,14" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/progress.png" borderWidth="2" borderColor="#0284c7" backgroundColor="#1e1035" foregroundColor="#38bdf8" zPosition="3" />
    <widget name="percentage" position="1236,705" size="120,22" font="Regular;22" foregroundColor="#fde047" backgroundColor="#0c0714" transparent="1" zPosition="3" halign="left" />
    <widget name="speed" position="1366,705" size="306,22" font="Regular;22" foregroundColor="#38bdf8" backgroundColor="#0c0714" transparent="1" zPosition="3" halign="right" />
    <widget name="size" position="1236,730" size="436,22" font="Regular;20" foregroundColor="#fbbf24" backgroundColor="#0c0714" transparent="1" zPosition="3" halign="center" />
    <widget name="status" position="1236,754" size="436,28" font="Regular;20" foregroundColor="#f472b6" backgroundColor="#0c0714" transparent="1" zPosition="3" halign="center" />

    <!-- FOOTER BUTTONS -->
    <eLabel position="20,812" size="1684,93" backgroundColor="#0f111a" zPosition="-1" />
    <eLabel position="20,812" size="1684,2" backgroundColor="#be185d" zPosition="0" />
    <eLabel position="20,812" size="4,93" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="1700,812" size="4,93" backgroundColor="#e11d48" zPosition="1" />
    <eLabel position="20,903" size="1684,2" backgroundColor="#be185d" zPosition="1" />

    <eLabel position="40,824" size="395,68" backgroundColor="#1e111d" zPosition="1" />
    <eLabel position="40,824" size="395,2" backgroundColor="#e11d48" zPosition="2" />
    <eLabel position="40,824" size="3,68" backgroundColor="#e11d48" zPosition="2" />
    <eLabel position="432,824" size="3,68" backgroundColor="#e11d48" zPosition="2" />
    <eLabel position="40,890" size="395,2" backgroundColor="#e11d48" zPosition="2" />
    <ePixmap position="56,836" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/key_red.png" scale="1" transparent="1" alphatest="blend" zPosition="3" />
    <widget name="key_red" position="114,824" size="311,68" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#1e111d" transparent="1" zPosition="3" halign="left" valign="center" />

    <eLabel position="451,824" size="395,68" backgroundColor="#0d1f19" zPosition="1" />
    <eLabel position="451,824" size="395,2" backgroundColor="#059669" zPosition="2" />
    <eLabel position="451,824" size="3,68" backgroundColor="#059669" zPosition="2" />
    <eLabel position="843,824" size="3,68" backgroundColor="#059669" zPosition="2" />
    <eLabel position="451,890" size="395,2" backgroundColor="#059669" zPosition="2" />
    <ePixmap position="467,836" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/key_green.png" scale="1" transparent="1" alphatest="blend" zPosition="3" />
    <widget name="key_green" position="525,824" size="311,68" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#0d1f19" transparent="1" zPosition="3" halign="left" valign="center" />

    <eLabel position="862,824" size="395,68" backgroundColor="#1f180c" zPosition="1" />
    <eLabel position="862,824" size="395,2" backgroundColor="#d97706" zPosition="2" />
    <eLabel position="862,824" size="3,68" backgroundColor="#d97706" zPosition="2" />
    <eLabel position="1254,824" size="3,68" backgroundColor="#d97706" zPosition="2" />
    <eLabel position="862,890" size="395,2" backgroundColor="#d97706" zPosition="2" />
    <ePixmap position="878,836" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/key_yellow.png" scale="1" transparent="1" alphatest="blend" zPosition="3" />
    <widget name="key_yellow" position="936,824" size="311,68" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#1f180c" transparent="1" zPosition="3" halign="left" valign="center" />

    <eLabel position="1273,824" size="395,68" backgroundColor="#0f152b" zPosition="1" />
    <eLabel position="1273,824" size="395,2" backgroundColor="#4f46e5" zPosition="2" />
    <eLabel position="1273,824" size="3,68" backgroundColor="#4f46e5" zPosition="2" />
    <eLabel position="1665,824" size="3,68" backgroundColor="#4f46e5" zPosition="2" />
    <eLabel position="1273,890" size="395,2" backgroundColor="#4f46e5" zPosition="2" />
    <ePixmap position="1289,836" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Tarek-panel/images/key_blue.png" scale="1" transparent="1" alphatest="blend" zPosition="3" />
    <widget name="key_blue" position="1347,824" size="311,68" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#0f152b" transparent="1" zPosition="3" halign="left" valign="center" />
</screen>
"""

# Apply Auto-Scaling to Skin Layout dynamically
SKIN_LAYOUT = scale_skin_layout(RAW_SKIN_LAYOUT)

# =========================================================================
# Football on TV (LiveOnSat) - Added feature (Tools section)
# Shows today's / tomorrow's / whole-week football matches with the
# broadcasting channels, parsed live from liveonsat.com.
# =========================================================================
LIVEONSAT_BASE = "https://liveonsat.com/2day.php"

FOOTBALL_RAW_SKIN = """<screen name="FootballMatches" position="center,center" size="1420,940" title="Football on TV">
    <widget name="title" position="20,10" size="1380,55" font="Regular;34" halign="center" transparent="1" foregroundColor="#00ffcc00"/>
    <widget name="daylabel" position="20,70" size="1380,42" font="Regular;28" halign="center" transparent="1" foregroundColor="#00ffffff"/>
    <widget name="list" position="25,120" size="1370,725" font="Regular;25" itemHeight="36" scrollbarMode="showOnDemand"/>
    <widget name="status" position="20,852" size="1380,36" font="Regular;23" halign="center" transparent="1" foregroundColor="#00aaaaaa"/>
    <widget name="key_red" position="30,898" size="330,32" font="Regular;23" halign="center" transparent="1" foregroundColor="#00ff4040"/>
    <widget name="key_green" position="380,898" size="330,32" font="Regular;23" halign="center" transparent="1" foregroundColor="#0040ff40"/>
    <widget name="key_yellow" position="730,898" size="330,32" font="Regular;23" halign="center" transparent="1" foregroundColor="#00ffff40"/>
    <widget name="key_blue" position="1080,898" size="330,32" font="Regular;23" halign="center" transparent="1" foregroundColor="#004080ff"/>
</screen>"""

FOOTBALL_SKIN = scale_skin_layout(FOOTBALL_RAW_SKIN)

def _make_ms_skin(screen_name, title):
    try:
        raw = FOOTBALL_RAW_SKIN.replace('name="FootballMatches"', 'name="%s"' % screen_name)
        raw = raw.replace('title="Football on TV"', 'title="%s"' % title)
        return scale_skin_layout(raw)
    except Exception:
        return FOOTBALL_SKIN

WEATHER_SKIN = _make_ms_skin("MS_WeatherScreen", "Weather")
IPTV_SKIN = _make_ms_skin("MS_IPTVScreen", "IPTV")
KOS_SKIN = _make_ms_skin("MS_KingOfSatScreen", "Frequencies")
NEWS_SKIN = _make_ms_skin("MS_NewsScreen", "News")

def _strip_emoji(txt):
    try:
        return u''.join(ch for ch in txt if ord(ch) < 0x1F000).strip()
    except Exception:
        return txt

def _call_ui(fn):
    if sys.version_info >= (3, 0):
        try:
            from twisted.internet import reactor
            reactor.callFromThread(fn)
            return
        except Exception:
            pass
    fn()

def _los_clean(raw):
    try:
        txt = re.sub(r'<[^>]+>', '', raw)
        for a, b in [('&amp;', '&'), ('&nbsp;', ' '), ('&ndash;', '-'),
                     ('&quot;', '"'), ('&#039;', "'"), ('&deg;', 'deg'),
                     ('&lt;', '<'), ('&gt;', '>')]:
            txt = txt.replace(a, b)
        # drop emoji / high codepoints that box fonts cannot render
        txt = u''.join(ch for ch in txt if ord(ch) < 0x1F000)
        return txt.strip()
    except Exception:
        return raw.strip()

def parse_liveonsat(html):
    """Parse the liveonsat schedule page into a list of match dicts."""
    matches = []
    try:
        team_re = re.compile(r'<div class = fLeft style="[^"]*#ffd379[^"]*">(.*?)</div>', re.S)
        comp_re = re.compile(r'<span class = comp_head>(.*?)</span>', re.S)
        day_re = re.compile(r'<h2 class = time_head>(.*?)</h2>', re.S)
        time_re = re.compile(r'ST:\s*([0-9]{1,2}:[0-9]{2})')
        chan_re = re.compile(r'onmouseout="return nd\(\);">(.*?)</a>', re.S)

        comps = [(m.start(), _los_clean(m.group(1))) for m in comp_re.finditer(html)]
        days = [(m.start(), _los_clean(m.group(1))) for m in day_re.finditer(html)]
        teams = list(team_re.finditer(html))

        for i, tm in enumerate(teams):
            start = tm.start()
            end = teams[i + 1].start() if i + 1 < len(teams) else len(html)
            block = html[start:end]

            comp = ""
            for pos, name in comps:
                if pos < start:
                    comp = name
                else:
                    break
            day = ""
            for pos, name in days:
                if pos < start:
                    day = name
                else:
                    break

            team = _los_clean(tm.group(1))
            tmo = time_re.search(block)
            stime = tmo.group(1) if tmo else "--:--"

            chans = []
            for cm in chan_re.finditer(block):
                c = _los_clean(cm.group(1))
                if c and c not in chans:
                    chans.append(c)

            if team:
                matches.append({
                    "day": day, "comp": comp, "team": team,
                    "time": stime, "channels": chans
                })
    except Exception:
        pass
    return matches

def fetch_liveonsat(start_date, end_date):
    """Download the liveonsat page for the given date range. Returns (ok, html_or_err)."""
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
        else:
            import urllib2
            import ssl
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None

        url = ("%s?start_dd=%02d&start_mm=%02d&start_yyyy=%d"
               "&end_dd=%02d&end_mm=%02d&end_yyyy=%d#") % (
            LIVEONSAT_BASE,
            start_date.day, start_date.month, start_date.year,
            end_date.day, end_date.month, end_date.year)

        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
        if context:
            resp = urllib2.urlopen(req, timeout=20, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=20)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        return True, data
    except Exception as e:
        return False, str(e)

class FootballMatches(Screen):
    skin = FOOTBALL_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label(u"\u26bd \u0645\u0628\u0627\u0631\u064a\u0627\u062a \u0627\u0644\u064a\u0648\u0645 \u0648\u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0646\u0627\u0642\u0644\u0629 (Football on TV)")
        self["daylabel"] = Label("")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["key_red"] = Label(u"\u062e\u0631\u0648\u062c (Exit)")
        self["key_green"] = Label(u"\u062a\u062d\u062f\u064a\u062b (Refresh)")
        self["key_yellow"] = Label(u"\u064a\u0648\u0645 \u0633\u0627\u0628\u0642 (Prev)")
        self["key_blue"] = Label(u"\u064a\u0648\u0645 \u062a\u0627\u0644\u064a (Next)")

        self.day_offset = 0
        self.week_mode = False
        self.is_loading = False

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.close,
            "ok": self.reload_matches,
            "red": self.close,
            "green": self.reload_matches,
            "yellow": self.prev_day,
            "blue": self.next_day,
            "left": self.prev_day,
            "right": self.next_day,
        }, -1)

        self.onLayoutFinish.append(self.reload_matches)

    def _get_dates(self):
        import datetime
        today = datetime.date.today()
        if self.week_mode:
            start = today
            end = today + datetime.timedelta(days=6)
        else:
            start = today + datetime.timedelta(days=self.day_offset)
            end = start
        return start, end

    def _day_title(self):
        import datetime
        if self.week_mode:
            return u"\u0643\u0627\u0645\u0644 \u0627\u0644\u0623\u0633\u0628\u0648\u0639 (Whole Week)"
        names = {
            0: u"\u0645\u0628\u0627\u0631\u064a\u0627\u062a \u0627\u0644\u064a\u0648\u0645 (Today)",
            1: u"\u0645\u0628\u0627\u0631\u064a\u0627\u062a \u063a\u062f\u0627\u064b (Tomorrow)",
            2: u"\u0628\u0639\u062f \u063a\u062f (Day After Tomorrow)",
        }
        base = names.get(self.day_offset)
        d = datetime.date.today() + datetime.timedelta(days=self.day_offset)
        ds = d.strftime("%A %d/%m/%Y")
        if base:
            return "%s  -  %s" % (base, ds)
        return ds

    def prev_day(self):
        if self.is_loading:
            return
        self.week_mode = False
        self.day_offset -= 1
        self.reload_matches()

    def next_day(self):
        if self.is_loading:
            return
        self.week_mode = False
        self.day_offset += 1
        self.reload_matches()

    def reload_matches(self):
        if self.is_loading:
            return
        self.is_loading = True
        self["daylabel"].setText(self._day_title())
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u062a\u062d\u0645\u064a\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u064a\u0627\u062a... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631... (Please wait)")
        start, end = self._get_dates()

        def _worker():
            ok, payload = fetch_liveonsat(start, end)
            matches = parse_liveonsat(payload) if ok else []

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0645\u0648\u0642\u0639 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Network error)")
                    return
                self._render(matches)

            if sys.version_info >= (3, 0):
                try:
                    from twisted.internet import reactor
                    reactor.callFromThread(_apply)
                except Exception:
                    _apply()
            else:
                _apply()

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _render(self, matches):
        entries = []
        if not matches:
            entries.append(u"\u0644\u0627 \u062a\u0648\u062c\u062f \u0645\u0628\u0627\u0631\u064a\u0627\u062a \u0644\u0647\u0630\u0627 \u0627\u0644\u064a\u0648\u0645 (No matches found)")
            self["list"].setList(entries)
            self["status"].setText("0 \u0645\u0628\u0627\u0631\u0627\u0629")
            return

        last_day = None
        for m in matches:
            if self.week_mode and m.get("day") and m["day"] != last_day:
                last_day = m["day"]
                entries.append(u"==== %s ====" % m["day"])
            header = u"\u23f0 %s   %s" % (m["time"], m["team"])
            entries.append(header)
            if m.get("comp"):
                entries.append(u"      \u2022 %s" % m["comp"])
            chans = m.get("channels") or []
            if chans:
                per = []
                for c in chans:
                    per.append(c)
                    if len(per) >= 3:
                        entries.append(u"      " + " , ".join(per))
                        per = []
                if per:
                    entries.append(u"      " + " , ".join(per))
            else:
                entries.append(u"      (\u0644\u0627 \u062a\u0648\u062c\u062f \u0642\u0646\u0627\u0629 / no channel listed)")
            entries.append(" ")

        self["list"].setList(entries)
        self["status"].setText(u"%d \u0645\u0628\u0627\u0631\u0627\u0629  |  \u0627\u0644\u0623\u0632\u0631\u0627\u0631: \u0623\u0635\u0641\u0631=\u0633\u0627\u0628\u0642  \u0623\u0632\u0631\u0642=\u062a\u0627\u0644\u064a  \u0623\u062e\u0636\u0631=\u062a\u062d\u062f\u064a\u062b" % len(matches))

# =========================================================================
# Weather (open-meteo) - Added feature (Tools section)
# =========================================================================
WEATHER_CITIES = [
    (u"\u0628\u063a\u062f\u0627\u062f (Baghdad)", 33.34, 44.40),
    (u"\u0627\u0644\u0628\u0635\u0631\u0629 (Basra)", 30.51, 47.78),
    (u"\u0623\u0631\u0628\u064a\u0644 (Erbil)", 36.19, 44.01),
    (u"\u0627\u0644\u0645\u0648\u0635\u0644 (Mosul)", 36.34, 43.13),
    (u"\u0627\u0644\u0646\u062c\u0641 (Najaf)", 32.00, 44.33),
    (u"\u0643\u0631\u0628\u0644\u0627\u0621 (Karbala)", 32.61, 44.02),
    (u"\u0627\u0644\u0642\u0627\u0647\u0631\u0629 (Cairo)", 30.04, 31.24),
    (u"\u0627\u0644\u0631\u064a\u0627\u0636 (Riyadh)", 24.71, 46.68),
    (u"\u062c\u062f\u0629 (Jeddah)", 21.49, 39.19),
    (u"\u0645\u0643\u0629 (Makkah)", 21.39, 39.86),
    (u"\u0627\u0644\u0645\u062f\u064a\u0646\u0629 (Madinah)", 24.52, 39.57),
    (u"\u062f\u0628\u064a (Dubai)", 25.20, 55.27),
    (u"\u0623\u0628\u0648\u0638\u0628\u064a (Abu Dhabi)", 24.45, 54.38),
    (u"\u0639\u0645\u0627\u0646 (Amman)", 31.95, 35.93),
    (u"\u062f\u0645\u0634\u0642 (Damascus)", 33.51, 36.29),
    (u"\u0628\u064a\u0631\u0648\u062a (Beirut)", 33.89, 35.50),
    (u"\u0627\u0644\u062f\u0648\u062d\u0629 (Doha)", 25.28, 51.53),
    (u"\u0627\u0644\u0643\u0648\u064a\u062a (Kuwait)", 29.37, 47.98),
    (u"\u0627\u0644\u0645\u0646\u0627\u0645\u0629 (Manama)", 26.22, 50.58),
    (u"\u0645\u0633\u0642\u0637 (Muscat)", 23.59, 58.41),
    (u"\u0635\u0646\u0639\u0627\u0621 (Sanaa)", 15.37, 44.19),
    (u"\u0627\u0644\u062e\u0631\u0637\u0648\u0645 (Khartoum)", 15.50, 32.56),
    (u"\u0637\u0631\u0627\u0628\u0644\u0633 (Tripoli)", 32.89, 13.19),
    (u"\u062a\u0648\u0646\u0633 (Tunis)", 36.81, 10.18),
    (u"\u0627\u0644\u062c\u0632\u0627\u0626\u0631 (Algiers)", 36.75, 3.06),
    (u"\u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621 (Casablanca)", 33.57, -7.59),
    (u"\u0627\u0644\u0631\u0628\u0627\u0637 (Rabat)", 34.02, -6.83),
    (u"\u0627\u0633\u0637\u0646\u0628\u0648\u0644 (Istanbul)", 41.01, 28.98),
    (u"\u0623\u0646\u0642\u0631\u0629 (Ankara)", 39.93, 32.86),
    (u"\u0637\u0647\u0631\u0627\u0646 (Tehran)", 35.69, 51.39),
    (u"\u0644\u0646\u062f\u0646 (London)", 51.51, -0.13),
    (u"\u0628\u0627\u0631\u064a\u0633 (Paris)", 48.85, 2.35),
    (u"\u0628\u0631\u0644\u064a\u0646 (Berlin)", 52.52, 13.40),
    (u"\u0631\u0648\u0645\u0627 (Rome)", 41.90, 12.50),
    (u"\u0645\u062f\u0631\u064a\u062f (Madrid)", 40.42, -3.70),
    (u"\u0645\u0648\u0633\u0643\u0648 (Moscow)", 55.75, 37.62),
    (u"\u0646\u064a\u0648\u064a\u0648\u0631\u0643 (New York)", 40.71, -74.01),
    (u"\u0648\u0627\u0634\u0646\u0637\u0646 (Washington)", 38.90, -77.04),
    (u"\u062a\u0648\u0631\u0646\u062a\u0648 (Toronto)", 43.65, -79.38),
    (u"\u0637\u0648\u0643\u064a\u0648 (Tokyo)", 35.68, 139.69),
    (u"\u0628\u0643\u064a\u0646 (Beijing)", 39.90, 116.41),
    (u"\u0646\u064a\u0648\u062f\u0644\u0647\u064a (New Delhi)", 28.61, 77.21),
    (u"\u0625\u0633\u0644\u0627\u0645 \u0623\u0628\u0627\u062f (Islamabad)", 33.68, 73.05),
    (u"\u0643\u0648\u0627\u0644\u0627\u0644\u0645\u0628\u0648\u0631 (Kuala Lumpur)", 3.14, 101.69),
    (u"\u062c\u0627\u0643\u0631\u062a\u0627 (Jakarta)", -6.21, 106.85),
    (u"\u0633\u064a\u062f\u0646\u064a (Sydney)", -33.87, 151.21),
]

WEATHER_CODES = {
    0: u"\u0635\u0627\u0641\u064a \u2600", 1: u"\u0635\u0627\u0641\u064d \u063a\u0627\u0644\u0628\u0627\u064b \U0001F324",
    2: u"\u063a\u0627\u0626\u0645 \u062c\u0632\u0626\u064a\u0627\u064b \u26c5", 3: u"\u063a\u0627\u0626\u0645 \u2601",
    45: u"\u0636\u0628\u0627\u0628 \U0001F32B", 48: u"\u0636\u0628\u0627\u0628 \U0001F32B",
    51: u"\u0631\u0630\u0627\u0630 \U0001F327", 53: u"\u0631\u0630\u0627\u0630 \U0001F327", 55: u"\u0631\u0630\u0627\u0630 \U0001F327",
    61: u"\u0645\u0637\u0631 \u062e\u0641\u064a\u0641 \U0001F327", 63: u"\u0645\u0637\u0631 \U0001F327", 65: u"\u0645\u0637\u0631 \u063a\u0632\u064a\u0631 \U0001F327",
    71: u"\u062b\u0644\u062c \u2744", 73: u"\u062b\u0644\u062c \u2744", 75: u"\u062b\u0644\u062c \u2744",
    80: u"\u0632\u062e\u0627\u062a \u0645\u0637\u0631 \U0001F326", 81: u"\u0632\u062e\u0627\u062a \u0645\u0637\u0631 \U0001F326", 82: u"\u0632\u062e\u0627\u062a \u063a\u0632\u064a\u0631\u0629 \U0001F326",
    95: u"\u0639\u0627\u0635\u0641\u0629 \u0631\u0639\u062f\u064a\u0629 \u26c8", 96: u"\u0639\u0627\u0635\u0641\u0629 \u0631\u0639\u062f\u064a\u0629 \u26c8", 99: u"\u0639\u0627\u0635\u0641\u0629 \u0631\u0639\u062f\u064a\u0629 \u26c8",
}

def _weather_desc(code):
    try:
        d = WEATHER_CODES.get(int(code), u"-")
        return u''.join(ch for ch in d if ord(ch) < 0x1F000).strip()
    except Exception:
        return u"-"

def fetch_weather(lat, lon):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
        else:
            import urllib2
            import ssl
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
               "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
               "&daily=temperature_2m_max,temperature_2m_min,weather_code"
               "&timezone=auto&forecast_days=5") % (lat, lon)
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        if context:
            resp = urllib2.urlopen(req, timeout=15, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=15)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        return True, json.loads(data)
    except Exception as e:
        return False, str(e)

def fetch_geocode(query):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import urllib.parse as urlparse
            import ssl
            q = urlparse.quote(query)
        else:
            import urllib2
            import urllib as urlparse
            import ssl
            q = urlparse.quote(query.encode('utf-8'))
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        url = ("https://geocoding-api.open-meteo.com/v1/search?name=%s"
               "&count=10&language=ar&format=json") % q
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        if context:
            resp = urllib2.urlopen(req, timeout=15, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=15)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        j = json.loads(data)
        results = []
        for r in j.get("results", []) or []:
            nm = r.get("name", "")
            country = r.get("country", "")
            admin = r.get("admin1", "")
            label = nm
            if admin and admin != nm:
                label += u", " + admin
            if country:
                label += u" - " + country
            results.append((label, r.get("latitude"), r.get("longitude")))
        return True, results
    except Exception as e:
        return False, str(e)

class WeatherScreen(Screen):
    skin = WEATHER_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label(u"\U0001F324 \u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0642\u0633 (Weather - open-meteo)")
        try:
            self.setTitle(u"\u062d\u0627\u0644\u0629 \u0627\u0644\u0637\u0642\u0633 (Weather)")
        except Exception:
            pass
        self["daylabel"] = Label("")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["key_red"] = Label(u"\u0631\u062c\u0648\u0639 (Back)")
        self["key_green"] = Label(u"\u0639\u0631\u0636 (Open)")
        self["key_yellow"] = Label(u"\u0628\u062d\u062b \u0639\u0646 \u0645\u062f\u064a\u0646\u0629 (Search)")
        self["key_blue"] = Label(u"\u062a\u062d\u062f\u064a\u062b (Refresh)")
        self.mode = "menu"
        self.is_loading = False
        self.search_results = []
        self.cur_city = None
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.ok_pressed,
            "red": self.go_back, "green": self.ok_pressed,
            "yellow": self.do_search, "blue": self.refresh_current,
        }, -1)
        self.onLayoutFinish.append(self.show_menu)

    def show_menu(self):
        self.mode = "menu"
        self["daylabel"].setText(u"\u0627\u062e\u062a\u0631 \u0645\u062f\u064a\u0646\u0629 \u0623\u0648 \u0627\u0636\u063a\u0637 \u0623\u0635\u0641\u0631 \u0644\u0644\u0628\u062d\u062b (Select or Search)")
        items = [u"\U0001F50D \u0628\u062d\u062b \u0639\u0646 \u0645\u062f\u064a\u0646\u0629 \u0641\u064a \u0627\u0644\u0639\u0627\u0644\u0645 (Search city)"]
        items += [c[0] for c in WEATHER_CITIES]
        self["list"].setList([_strip_emoji(x) for x in items])
        self["status"].setText(u"OK = \u0639\u0631\u0636 \u0627\u0644\u0637\u0642\u0633  |  \u0623\u0635\u0641\u0631 = \u0628\u062d\u062b")

    def go_back(self):
        if self.is_loading:
            return
        if self.mode in ("detail", "search"):
            self.show_menu()
        else:
            self.close()

    def ok_pressed(self):
        if self.is_loading:
            return
        idx = self["list"].getSelectionIndex()
        if idx < 0:
            return
        if self.mode == "menu":
            if idx == 0:
                self.do_search()
            else:
                c = WEATHER_CITIES[idx - 1]
                self.cur_city = (c[0], c[1], c[2])
                self.load_detail()
        elif self.mode == "search":
            if 0 <= idx < len(self.search_results):
                r = self.search_results[idx]
                self.cur_city = (r[0], r[1], r[2])
                self.load_detail()

    def refresh_current(self):
        if self.mode == "detail" and self.cur_city and not self.is_loading:
            self.load_detail()

    def do_search(self):
        if self.is_loading:
            return
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(self._search_cb, VirtualKeyBoard,
                                          title=u"\u0627\u0643\u062a\u0628 \u0627\u0633\u0645 \u0627\u0644\u0645\u062f\u064a\u0646\u0629 (City name)")
        except Exception as e:
            self.session.open(MessageBox, u"\u062a\u0639\u0630\u0631 \u0641\u062a\u062d \u0644\u0648\u062d\u0629 \u0627\u0644\u0645\u0641\u0627\u062a\u064a\u062d:\n%s" % str(e), MessageBox.TYPE_ERROR)

    def _search_cb(self, text):
        if not text:
            return
        self.is_loading = True
        self.mode = "search"
        self["daylabel"].setText(u"\u0646\u062a\u0627\u0626\u062c \u0627\u0644\u0628\u062d\u062b: %s" % text)
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u0628\u062d\u062b... (Searching...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            ok, payload = fetch_geocode(text)

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644")
                    return
                self.search_results = payload
                if not payload:
                    self["list"].setList([u"\u0644\u0627 \u062a\u0648\u062c\u062f \u0646\u062a\u0627\u0626\u062c (No results)"])
                    self["status"].setText(u"\u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639")
                else:
                    self["list"].setList([_strip_emoji(r[0]) for r in payload])
                    self["status"].setText(u"%d \u0646\u062a\u064a\u062c\u0629  |  OK = \u0639\u0631\u0636 \u0627\u0644\u0637\u0642\u0633  |  \u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639" % len(payload))

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def load_detail(self):
        self.is_loading = True
        self.mode = "detail"
        name, lat, lon = self.cur_city
        self["daylabel"].setText(name)
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            ok, payload = fetch_weather(lat, lon)

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644")
                    return
                self._render(payload)

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _render(self, data):
        entries = []
        try:
            cur = data.get("current", {})
            entries.append(u"\u2554\u2550 \u0627\u0644\u0622\u0646 (Now) \u2550\u2557")
            entries.append(u"  \u0627\u0644\u062d\u0631\u0627\u0631\u0629: %s\u00b0C" % cur.get("temperature_2m", "-"))
            entries.append(u"  \u0627\u0644\u062d\u0627\u0644\u0629: %s" % _weather_desc(cur.get("weather_code", -1)))
            entries.append(u"  \u0627\u0644\u0631\u0637\u0648\u0628\u0629: %s%%" % cur.get("relative_humidity_2m", "-"))
            entries.append(u"  \u0627\u0644\u0631\u064a\u0627\u062d: %s km/h" % cur.get("wind_speed_10m", "-"))
            entries.append(" ")
            entries.append(u"\u2554\u2550 \u062a\u0648\u0642\u0639\u0627\u062a 5 \u0623\u064a\u0627\u0645 (5-Day) \u2550\u2557")
            daily = data.get("daily", {})
            days = daily.get("time", [])
            tmax = daily.get("temperature_2m_max", [])
            tmin = daily.get("temperature_2m_min", [])
            wc = daily.get("weather_code", [])
            for i in range(len(days)):
                mx = tmax[i] if i < len(tmax) else "-"
                mn = tmin[i] if i < len(tmin) else "-"
                cc = wc[i] if i < len(wc) else -1
                entries.append(u"  %s   %s\u00b0/%s\u00b0   %s" % (days[i], mx, mn, _weather_desc(cc)))
        except Exception as e:
            entries.append(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0628\u064a\u0627\u0646\u0627\u062a: %s" % str(e))
        self["list"].setList(entries)
        self["status"].setText(u"\u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639  |  \u0623\u0632\u0631\u0642 = \u062a\u062d\u062f\u064a\u062b")

# =========================================================================
# IPTV (iptv-org) - Added feature (Tools section)
# =========================================================================
IPTV_COUNTRIES = [
    (u"\u0627\u0644\u0639\u0631\u0627\u0642 (Iraq)", "iq"),
    (u"\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629 (Saudi Arabia)", "sa"),
    (u"\u0645\u0635\u0631 (Egypt)", "eg"),
    (u"\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a (UAE)", "ae"),
    (u"\u0627\u0644\u0623\u0631\u062f\u0646 (Jordan)", "jo"),
    (u"\u0627\u0644\u0643\u0648\u064a\u062a (Kuwait)", "kw"),
    (u"\u0642\u0637\u0631 (Qatar)", "qa"),
    (u"\u0627\u0644\u0645\u063a\u0631\u0628 (Morocco)", "ma"),
    (u"\u0627\u0644\u062c\u0632\u0627\u0626\u0631 (Algeria)", "dz"),
    (u"\u062a\u0648\u0646\u0633 (Tunisia)", "tn"),
    (u"\u0644\u0628\u0646\u0627\u0646 (Lebanon)", "lb"),
    (u"\u0633\u0648\u0631\u064a\u0627 (Syria)", "sy"),
    (u"\u0641\u0644\u0633\u0637\u064a\u0646 (Palestine)", "ps"),
    (u"\u0644\u064a\u0628\u064a\u0627 (Libya)", "ly"),
    (u"\u0627\u0644\u0633\u0648\u062f\u0627\u0646 (Sudan)", "sd"),
    (u"\u0639\u0645\u0627\u0646 (Oman)", "om"),
    (u"\u0627\u0644\u064a\u0645\u0646 (Yemen)", "ye"),
    (u"\u0643\u0644 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0639\u0631\u0628\u064a\u0629 (All Arabic)", "@ara"),
]

def fetch_iptv(code):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
        else:
            import urllib2
            import ssl
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        if code == "@ara":
            url = "https://iptv-org.github.io/iptv/languages/ara.m3u"
        else:
            url = "https://iptv-org.github.io/iptv/countries/%s.m3u" % code
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        if context:
            resp = urllib2.urlopen(req, timeout=20, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=20)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        return True, data
    except Exception as e:
        return False, str(e)

def parse_m3u(text):
    channels = []
    try:
        name = None
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#EXTINF"):
                if "," in line:
                    name = line.split(",", 1)[1].strip()
                else:
                    name = "Channel"
            elif line and not line.startswith("#"):
                if name:
                    channels.append((name, line))
                    name = None
    except Exception:
        pass
    return channels

IPTV_BASE = "https://iptv-org.github.io/iptv"
IPTV_API = "https://iptv-org.github.io/api"

IPTV_AR_COUNTRY = {
    "iq": u"\u0627\u0644\u0639\u0631\u0627\u0642", "sa": u"\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629",
    "eg": u"\u0645\u0635\u0631", "ae": u"\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a",
    "jo": u"\u0627\u0644\u0623\u0631\u062f\u0646", "kw": u"\u0627\u0644\u0643\u0648\u064a\u062a",
    "qa": u"\u0642\u0637\u0631", "ma": u"\u0627\u0644\u0645\u063a\u0631\u0628",
    "dz": u"\u0627\u0644\u062c\u0632\u0627\u0626\u0631", "tn": u"\u062a\u0648\u0646\u0633",
    "lb": u"\u0644\u0628\u0646\u0627\u0646", "sy": u"\u0633\u0648\u0631\u064a\u0627",
    "ps": u"\u0641\u0644\u0633\u0637\u064a\u0646", "ly": u"\u0644\u064a\u0628\u064a\u0627",
    "sd": u"\u0627\u0644\u0633\u0648\u062f\u0627\u0646", "om": u"\u0639\u0645\u0627\u0646",
    "ye": u"\u0627\u0644\u064a\u0645\u0646", "bh": u"\u0627\u0644\u0628\u062d\u0631\u064a\u0646",
    "mr": u"\u0645\u0648\u0631\u064a\u062a\u0627\u0646\u064a\u0627", "so": u"\u0627\u0644\u0635\u0648\u0645\u0627\u0644",
    "dj": u"\u062c\u064a\u0628\u0648\u062a\u064a", "km": u"\u062c\u0632\u0631 \u0627\u0644\u0642\u0645\u0631",
    "tr": u"\u062a\u0631\u0643\u064a\u0627", "ir": u"\u0625\u064a\u0631\u0627\u0646",
    "us": u"\u0627\u0644\u0648\u0644\u0627\u064a\u0627\u062a \u0627\u0644\u0645\u062a\u062d\u062f\u0629", "gb": u"\u0628\u0631\u064a\u0637\u0627\u0646\u064a\u0627",
    "fr": u"\u0641\u0631\u0646\u0633\u0627", "de": u"\u0623\u0644\u0645\u0627\u0646\u064a\u0627",
}

def _http_get(url, timeout=25):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
        else:
            import urllib2
            import ssl
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        if context:
            resp = urllib2.urlopen(req, timeout=timeout, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=timeout)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        return True, data
    except Exception as e:
        return False, str(e)

def fetch_iptv_index():
    index = []
    index.append((u"\u2605 \u0643\u0644 \u0627\u0644\u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0639\u0631\u0628\u064a\u0629 (All Arabic)", IPTV_BASE + "/languages/ara.m3u"))
    okc, cdata = _http_get(IPTV_API + "/categories.json")
    if okc:
        try:
            for c in json.loads(cdata):
                cid = c.get("id")
                nm = c.get("name", "")
                if cid:
                    index.append((u"[\u062a\u0635\u0646\u064a\u0641] %s" % nm, IPTV_BASE + "/categories/%s.m3u" % cid))
        except Exception:
            pass
    oks, sdata = _http_get(IPTV_API + "/countries.json")
    if oks:
        try:
            arr = json.loads(sdata)
            arr = sorted(arr, key=lambda x: x.get("name", ""))
            for c in arr:
                code = c.get("code")
                nm = c.get("name", "")
                if code:
                    ar = IPTV_AR_COUNTRY.get(code.lower())
                    label = (u"%s (%s)" % (ar, nm)) if ar else nm
                    index.append((label, IPTV_BASE + "/countries/%s.m3u" % code.lower()))
        except Exception:
            pass
    return index

class IPTVScreen(Screen):
    skin = IPTV_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label(u"\U0001F4FA \u0642\u0646\u0648\u0627\u062a IPTV (iptv-org)")
        try:
            self.setTitle(u"\u0642\u0646\u0648\u0627\u062a IPTV (IPTV)")
        except Exception:
            pass
        self["daylabel"] = Label("")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["key_red"] = Label(u"\u0631\u062c\u0648\u0639 (Back)")
        self["key_green"] = Label(u"\u062a\u0634\u063a\u064a\u0644 (Play)")
        self["key_yellow"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0639\u0644\u0649 (Page Up)")
        self["key_blue"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0633\u0641\u0644 (Page Down)")
        self.mode = "menu"
        self.index = []
        self.is_loading = False
        self.channels = []
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.ok_pressed,
            "red": self.go_back, "green": self.ok_pressed,
            "yellow": self.page_up, "blue": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.load_index)

    def page_up(self):
        try:
            self["list"].pageUp()
        except Exception:
            pass

    def page_down(self):
        try:
            self["list"].pageDown()
        except Exception:
            pass

    def load_index(self):
        self.is_loading = True
        self.mode = "menu"
        self["daylabel"].setText(u"\u062c\u0627\u0631\u064a \u062a\u062d\u0645\u064a\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062f\u0648\u0644 \u0648\u0627\u0644\u062a\u0635\u0646\u064a\u0641\u0627\u062a... (Loading...)")
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            index = fetch_iptv_index()

            def _apply():
                self.is_loading = False
                if not index:
                    self.index = [(c[0], (IPTV_BASE + "/languages/ara.m3u") if c[1] == "@ara" else (IPTV_BASE + "/countries/%s.m3u" % c[1])) for c in IPTV_COUNTRIES]
                else:
                    self.index = index
                self.show_menu()

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def show_menu(self):
        self.mode = "menu"
        self["daylabel"].setText(u"\u0627\u062e\u062a\u0631 \u062f\u0648\u0644\u0629 \u0623\u0648 \u062a\u0635\u0646\u064a\u0641 \u062b\u0645 OK (Select then OK)")
        self["list"].setList([_strip_emoji(x[0]) for x in self.index])
        self["status"].setText(u"%d \u0639\u0646\u0635\u0631  |  OK = \u0641\u062a\u062d \u0627\u0644\u0642\u0646\u0648\u0627\u062a  |  \u0623\u0635\u0641\u0631/\u0623\u0632\u0631\u0642 = \u062a\u0635\u0641\u062d" % len(self.index))

    def go_back(self):
        if self.is_loading:
            return
        if self.mode == "channels":
            self.show_menu()
        else:
            self.close()

    def ok_pressed(self):
        if self.is_loading:
            return
        idx = self["list"].getSelectionIndex()
        if idx < 0:
            return
        if self.mode == "menu":
            if 0 <= idx < len(self.index):
                self.load_channels(self.index[idx])
        else:
            if 0 <= idx < len(self.channels):
                self.play_channel(self.channels[idx])

    def load_channels(self, entry):
        self.is_loading = True
        name, url = entry
        self["daylabel"].setText(_strip_emoji(name))
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            ok, payload = _http_get(url, 25)
            chans = parse_m3u(payload) if ok else []

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644")
                    return
                self.mode = "channels"
                self.channels = chans
                if not chans:
                    self["list"].setList([u"\u0644\u0627 \u062a\u0648\u062c\u062f \u0642\u0646\u0648\u0627\u062a (No channels)"])
                else:
                    self["list"].setList([u"%d. %s" % (i + 1, _strip_emoji(c[0])) for i, c in enumerate(chans)])
                self["status"].setText(u"%d \u0642\u0646\u0627\u0629  |  OK = \u062a\u0634\u063a\u064a\u0644  |  \u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639  |  \u0645\u0644\u0627\u062d\u0638\u0629: \u0642\u0646\u0648\u0627\u062a \u0627\u0644\u0634\u064a\u0631\u0646\u0651\u064c \u063a\u064a\u0631 \u0645\u062a\u0648\u0641\u0631\u0629 \u0647\u0646\u0627" % len(chans))

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def play_channel(self, ch):
        name, url = ch
        try:
            from enigma import eServiceReference
            safe = url.replace(":", "%3a")
            ref = eServiceReference("4097:0:1:0:0:0:0:0:0:0:" + safe)
            try:
                ref.setName(name)
            except Exception:
                pass
            self.session.nav.playService(ref)
            self["status"].setText(u"\u062c\u0627\u0631\u064a \u062a\u0634\u063a\u064a\u0644: %s" % name)
        except Exception as e:
            self.session.open(MessageBox, u"\u062a\u0639\u0630\u0631 \u0627\u0644\u062a\u0634\u063a\u064a\u0644:\n%s" % str(e), MessageBox.TYPE_ERROR)

# =========================================================================
# KingOfSat frequencies - Added feature (Tools section)
# =========================================================================
KOS_SATS = [
    (u"\u0646\u0627\u064a\u0644 \u0633\u0627\u062a / Eutelsat 7W (7.0\u00b0W)", "7.0W"),
    (u"\u0639\u0631\u0628 \u0633\u0627\u062a / Badr (26.0\u00b0E)", "26.0E"),
    (u"\u0625\u0633 \u0647\u0627\u064a\u0644 (25.5\u00b0E)", "25.5E"),
    (u"\u0647\u0648\u062a \u0628\u064a\u0631\u062f (13.0\u00b0E)", "13.0E"),
    (u"Astra (19.2\u00b0E)", "19.2E"),
    (u"\u062a\u0631\u0643 \u0633\u0627\u062a (42.0\u00b0E)", "42.0E"),
    (u"\u064a\u0627\u0647 \u0633\u0627\u062a (52.5\u00b0E)", "52.5E"),
]

def fetch_kingofsat(pos):
    try:
        if sys.version_info >= (3, 0):
            import urllib.request as urllib2
            import ssl
        else:
            import urllib2
            import ssl
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        url = ("https://en.kingofsat.net/freqs.php?pos=%s&lim=0"
               "&standard=All&ordre=freq&filtre=no") % pos
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
        if context:
            resp = urllib2.urlopen(req, timeout=30, context=context)
        else:
            resp = urllib2.urlopen(req, timeout=30)
        data = resp.read()
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'ignore')
        return True, data
    except Exception as e:
        return False, str(e)

def parse_kingofsat(html):
    transponders = []
    try:
        hdr = re.compile(r'class="bld">(\d+\.\d+)</td>\s*<td[^>]*class="bld">([HVLR])</td>', re.I)
        srfec = re.compile(r'<a class="bld">(\d+)</a>\s*<a class="bld">(\d+/\d+)</a>', re.I)
        chan = re.compile(r'<td class="ch">(.*?)</td>', re.S | re.I)
        heads = list(hdr.finditer(html))
        for i, m in enumerate(heads):
            start = m.start()
            end = heads[i + 1].start() if i + 1 < len(heads) else len(html)
            block = html[start:end]
            freq = m.group(1)
            pol = m.group(2)
            sf = srfec.search(block)
            sr = sf.group(1) if sf else "?"
            fec = sf.group(2) if sf else "?"
            chans = []
            for c in chan.findall(block):
                name = _los_clean(c)
                if name and name.lower() != "name":
                    chans.append(name)
            if chans:
                transponders.append((freq, pol, sr, fec, chans))
    except Exception:
        pass
    return transponders

def fetch_kos_satellites():
    ok, html = _http_get("https://en.kingofsat.net/satellites.php", 30)
    if not ok:
        return []
    sats = []
    seen = set()
    try:
        for m in re.finditer(r'href="pos-([^"]+)"[^>]*>([^<]+)</a>', html):
            pos = m.group(1)
            postxt = _los_clean(m.group(2))
            tail = html[m.end():m.end() + 400]
            nm = re.search(r'href="sat-[^"]+"[^>]*>([^<]+)</a>', tail)
            name = _los_clean(nm.group(1)) if nm else ""
            if name:
                label = u"%s  (%s)" % (name, postxt)
            else:
                label = postxt
            key = (pos, name)
            if key in seen:
                continue
            seen.add(key)
            sats.append((label, pos))
    except Exception:
        return []
    return sats

class KingOfSatScreen(Screen):
    skin = KOS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label(u"\U0001F4E1 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0648\u0627\u0644\u0623\u0642\u0645\u0627\u0631 (KingOfSat)")
        try:
            self.setTitle(u"\u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a \u0648\u0627\u0644\u0623\u0642\u0645\u0627\u0631 (Frequencies)")
        except Exception:
            pass
        self["daylabel"] = Label("")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["key_red"] = Label(u"\u0631\u062c\u0648\u0639 (Back)")
        self["key_green"] = Label(u"\u0639\u0631\u0636 (Open)")
        self["key_yellow"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0639\u0644\u0649 (Page Up)")
        self["key_blue"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0633\u0641\u0644 (Page Down)")
        self.mode = "sats"
        self.sat_idx = 0
        self.is_loading = False
        self.sats = list(KOS_SATS)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.ok_pressed,
            "red": self.go_back, "green": self.ok_pressed,
            "yellow": self.prev_sat, "blue": self.next_sat,
        }, -1)
        self.onLayoutFinish.append(self.load_sats)

    def load_sats(self):
        self.is_loading = True
        self.mode = "sats"
        self["daylabel"].setText(u"\u062c\u0627\u0631\u064a \u062a\u062d\u0645\u064a\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0623\u0642\u0645\u0627\u0631... (Loading...)")
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            sats = fetch_kos_satellites()

            def _apply():
                self.is_loading = False
                if sats:
                    self.sats = sats
                else:
                    self.sats = list(KOS_SATS)
                self.show_sats()

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def show_sats(self):
        self.mode = "sats"
        self["daylabel"].setText(u"\u0627\u062e\u062a\u0631 \u0627\u0644\u0642\u0645\u0631 \u062b\u0645 OK (Select satellite)")
        self["list"].setList([_strip_emoji(s[0]) for s in self.sats])
        self["status"].setText(u"%d \u0642\u0645\u0631  |  OK = \u0639\u0631\u0636 \u0627\u0644\u062a\u0631\u062f\u062f\u0627\u062a  |  \u0623\u0635\u0641\u0631/\u0623\u0632\u0631\u0642 = \u062a\u0635\u0641\u062d" % len(self.sats))

    def prev_sat(self):
        if self.mode == "sats" and not self.is_loading:
            try:
                self["list"].pageUp()
            except Exception:
                pass

    def next_sat(self):
        if self.mode == "sats" and not self.is_loading:
            try:
                self["list"].pageDown()
            except Exception:
                pass

    def go_back(self):
        if self.mode == "freqs":
            self.show_sats()
        else:
            self.close()

    def ok_pressed(self):
        if self.is_loading:
            return
        if self.mode == "sats":
            self.sat_idx = self["list"].getSelectionIndex()
            if self.sat_idx < 0:
                return
            self.load_freqs()

    def load_freqs(self):
        self.is_loading = True
        name, pos = self.sats[self.sat_idx]
        self["daylabel"].setText(_strip_emoji(name))
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            ok, payload = fetch_kingofsat(pos)
            tps = parse_kingofsat(payload) if ok else []

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644")
                    return
                self.mode = "freqs"
                self._render(tps)

            if sys.version_info >= (3, 0):
                try:
                    from twisted.internet import reactor
                    reactor.callFromThread(_apply)
                except Exception:
                    _apply()
            else:
                _apply()

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def _render(self, tps):
        entries = []
        total = 0
        if not tps:
            entries.append(u"\u0644\u0627 \u062a\u0648\u062c\u062f \u0628\u064a\u0627\u0646\u0627\u062a (No data)")
        for freq, pol, sr, fec, chans in tps:
            total += len(chans)
            entries.append(u"\u2554\u2550 %s %s  SR:%s  FEC:%s \u2550\u2557" % (freq, pol, sr, fec))
            per = []
            for c in chans:
                per.append(c)
                if len(per) >= 2:
                    entries.append(u"   " + "  |  ".join(per))
                    per = []
            if per:
                entries.append(u"   " + "  |  ".join(per))
            entries.append(" ")
        self["list"].setList(entries)
        self["status"].setText(u"%d \u062a\u0631\u062f\u062f  |  %d \u0642\u0646\u0627\u0629  |  \u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639" % (len(tps), total))

# =========================================================================
# News (RSS) - Added feature (Tools section)
# =========================================================================
NEWS_FEEDS = [
    (u"\u0627\u0644\u062c\u0632\u064a\u0631\u0629 (Al Jazeera)", "https://www.aljazeera.net/aljazeerarss"),
    (u"\u0633\u0643\u0627\u064a \u0646\u064a\u0648\u0632 \u0639\u0631\u0628\u064a\u0629 (Sky News Arabia)", "https://www.skynewsarabia.com/rss"),
    (u"\u0628\u064a \u0628\u064a \u0633\u064a \u0639\u0631\u0628\u064a (BBC Arabic)", "https://feeds.bbci.co.uk/arabic/rss.xml"),
    (u"\u0631\u0648\u0633\u064a\u0627 \u0627\u0644\u064a\u0648\u0645 (RT Arabic)", "https://arabic.rt.com/rss/"),
    (u"\u0633\u064a \u0627\u0646 \u0627\u0646 \u0628\u0627\u0644\u0639\u0631\u0628\u064a\u0629 (CNN Arabic)", "https://arabic.cnn.com/api/v1/rss/rss.xml"),
    (u"\u0633\u064a \u0627\u0646 \u0627\u0646 - \u0631\u064a\u0627\u0636\u0629 (CNN Sports AR)", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml"),
]

def _rss_clean(raw):
    try:
        txt = raw
        m = re.search(r'<!\[CDATA\[(.*?)\]\]>', txt, re.S)
        if m:
            txt = m.group(1)
        txt = re.sub(r'<[^>]+>', '', txt)
        for a, b in [('&amp;', '&'), ('&nbsp;', ' '), ('&ndash;', '-'),
                     ('&mdash;', '-'), ('&quot;', '"'), ('&#039;', "'"),
                     ('&apos;', "'"), ('&lt;', '<'), ('&gt;', '>'), ('&laquo;', '"'), ('&raquo;', '"')]:
            txt = txt.replace(a, b)
        txt = u''.join(ch for ch in txt if ord(ch) < 0x1F000)
        return txt.strip()
    except Exception:
        return raw

def parse_rss(text):
    items = []
    try:
        blocks = re.findall(r'<item[ >](.*?)</item>', text, re.S | re.I)
        if not blocks:
            blocks = re.findall(r'<entry[ >](.*?)</entry>', text, re.S | re.I)
        for b in blocks:
            tm = re.search(r'<title>(.*?)</title>', b, re.S | re.I)
            title = _rss_clean(tm.group(1)) if tm else ""
            lm = re.search(r'<link>(.*?)</link>', b, re.S | re.I)
            link = _rss_clean(lm.group(1)) if lm else ""
            if not link:
                lm2 = re.search(r'<link[^>]*href="([^"]+)"', b, re.I)
                link = lm2.group(1) if lm2 else ""
            dm = re.search(r'<pubDate>(.*?)</pubDate>', b, re.S | re.I)
            pub = _rss_clean(dm.group(1)) if dm else ""
            gm = re.search(r'<description>(.*?)</description>', b, re.S | re.I)
            desc = _rss_clean(gm.group(1)) if gm else ""
            if title:
                items.append({"title": title, "link": link, "date": pub, "desc": desc})
    except Exception:
        pass
    return items

class NewsScreen(Screen):
    skin = NEWS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label(u"\U0001F4F0 \u0627\u0644\u0623\u062e\u0628\u0627\u0631 \u0627\u0644\u0639\u0627\u062c\u0644\u0629 (News - RSS)")
        try:
            self.setTitle(u"\u0627\u0644\u0623\u062e\u0628\u0627\u0631 \u0627\u0644\u0639\u0627\u062c\u0644\u0629 (News)")
        except Exception:
            pass
        self["daylabel"] = Label("")
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["key_red"] = Label(u"\u0631\u062c\u0648\u0639 (Back)")
        self["key_green"] = Label(u"\u0641\u062a\u062d (Open)")
        self["key_yellow"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0639\u0644\u0649 (Page Up)")
        self["key_blue"] = Label(u"\u0635\u0641\u062d\u0629 \u0644\u0623\u0633\u0641\u0644 (Page Down)")
        self.mode = "feeds"
        self.is_loading = False
        self.articles = []
        self.cur_feed = ""
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.ok_pressed,
            "red": self.go_back, "green": self.ok_pressed,
            "yellow": self.page_up, "blue": self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.show_feeds)

    def page_up(self):
        try:
            self["list"].pageUp()
        except Exception:
            pass

    def page_down(self):
        try:
            self["list"].pageDown()
        except Exception:
            pass

    def show_feeds(self):
        self.mode = "feeds"
        self["daylabel"].setText(u"\u0627\u062e\u062a\u0631 \u0627\u0644\u0645\u0635\u062f\u0631 \u062b\u0645 OK (Select source)")
        self["list"].setList([_strip_emoji(f[0]) for f in NEWS_FEEDS])
        self["status"].setText(u"OK = \u0639\u0631\u0636 \u0627\u0644\u0623\u062e\u0628\u0627\u0631")

    def go_back(self):
        if self.is_loading:
            return
        if self.mode == "articles":
            self.show_feeds()
        else:
            self.close()

    def ok_pressed(self):
        if self.is_loading:
            return
        idx = self["list"].getSelectionIndex()
        if idx < 0:
            return
        if self.mode == "feeds":
            if 0 <= idx < len(NEWS_FEEDS):
                self.load_articles(NEWS_FEEDS[idx])
        else:
            if 0 <= idx < len(self.articles):
                self.show_article(self.articles[idx])

    def load_articles(self, feed):
        self.is_loading = True
        name, url = feed
        self.cur_feed = name
        self["daylabel"].setText(_strip_emoji(name))
        self["list"].setList([u"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644... (Loading...)"])
        self["status"].setText(u"\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631...")

        def _worker():
            ok, payload = _http_get(url, 25)
            arts = parse_rss(payload) if ok else []

            def _apply():
                self.is_loading = False
                if not ok:
                    self["list"].setList([u"\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 (Connection failed)", str(payload)])
                    self["status"].setText(u"\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644")
                    return
                self.mode = "articles"
                self.articles = arts
                if not arts:
                    self["list"].setList([u"\u0644\u0627 \u062a\u0648\u062c\u062f \u0623\u062e\u0628\u0627\u0631 (No news)"])
                else:
                    self["list"].setList([u"%d. %s" % (i + 1, a["title"]) for i, a in enumerate(arts)])
                self["status"].setText(u"%d \u062e\u0628\u0631  |  OK = \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644  |  \u0623\u062d\u0645\u0631 = \u0631\u062c\u0648\u0639" % len(arts))

            _call_ui(_apply)

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def show_article(self, art):
        try:
            msg = art.get("title", "")
            if art.get("date"):
                msg += u"\n\n\U0001F551 " + art["date"]
            if art.get("desc"):
                msg += u"\n\n" + art["desc"]
            if art.get("link"):
                msg += u"\n\n\U0001F517 " + art["link"]
            msg = u''.join(ch for ch in msg if ord(ch) < 0x1F000 or ch in u"\U0001F551\U0001F517")
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, str(e), MessageBox.TYPE_ERROR)

class MohamedStore(Screen):
    skin = SKIN_LAYOUT

    def __init__(self, session):
        Screen.__init__(self, session)
        
        self.categories_list_has_multicontent = False
        if HAS_MULTICONTENT and eListboxPythonMultiContent:
            try:
                try:
                    self["categories_list"] = MenuList([], content=eListboxPythonMultiContent)
                except TypeError:
                    self["categories_list"] = MenuList([])
                    self["categories_list"].l = eListboxPythonMultiContent()
                
                if gFont:
                    try:
                        self["categories_list"].l.setFont(0, gFont("Regular", scale_font(30)))
                        self["categories_list"].l.setFont(1, gFont("Regular", scale_font(22)))
                    except Exception:
                        pass
                self["categories_list"].l.setBuildFunc(self.build_category_entry)
                self.categories_list_has_multicontent = True
            except Exception:
                self["categories_list"] = MenuList([])
        else:
            self["categories_list"] = MenuList([])

        self.items_list_has_multicontent = False
        if HAS_MULTICONTENT and eListboxPythonMultiContent:
            try:
                try:
                    self["items_list"] = MenuList([], content=eListboxPythonMultiContent)
                except TypeError:
                    self["items_list"] = MenuList([])
                    self["items_list"].l = eListboxPythonMultiContent()
                
                if gFont:
                    try:
                        self["items_list"].l.setFont(0, gFont("Regular", scale_font(32)))
                    except Exception:
                        pass
                self["items_list"].l.setBuildFunc(self.build_item_entry)
                self.items_list_has_multicontent = True
            except Exception:
                self["items_list"] = MenuList([])
        else:
            self["items_list"] = MenuList([])

        self["description"] = Label("Loading...")
        
        telemetry = self.get_system_telemetry_info()
        self["sys_device"] = Label(telemetry.get("device", "Box: Enigma2"))
        self["sys_image"] = Label(telemetry.get("image", "OS: EGAMI"))
        self["sys_cpu"] = Label(telemetry.get("cpu", "CPU: Active"))
        self["sys_temp"] = Label(telemetry.get("temp", "Temp: N/A"))
        self["sys_ram"] = Label(telemetry.get("ram", "RAM: OK"))
        self["sys_flash"] = Label(telemetry.get("flash", "Flash: OK"))
        
        real_ip = get_real_box_ip()
        self["sys_ip"] = Label("IP: %s" % real_ip)
        self["sys_net"] = Label("Net: Online")
        
        self["facebook_title"] = Label(u"\u062a\u0627\u0628\u0639\u0646\u0627 \u0639\u0644\u0649 \u0641\u064a\u0633\u0628\u0648\u0643")
        self["facebook_label"] = Label("https://www.facebook.com/share/1G8inRhUib/")
        
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Install")
        self["key_yellow"] = Label("Refresh Store")
        self["key_blue"] = Label("Update Store")
        
        if ProgressBar:
            self["progress"] = ProgressBar()
        else:
            self["progress"] = Label("")
        self["percentage"] = Label("")
        self["speed"] = Label("")
        self["size"] = Label("")
        self["status"] = Label("")

        try:
            self["progress"].hide()
            self["percentage"].hide()
            self["speed"].hide()
            self["size"].hide()
            self["status"].hide()
        except Exception:
            pass

        self.download_in_progress = False
        self.download_is_update_script = False
        self.download_is_system_image = False
        self.download_is_picon = False
        self.download_url = ""
        self.download_dest_path = ""
        self.download_aborted = False
        self.download_completed = False
        self.download_error_msg = ""
        self.download_total_bytes = 0
        self.downloaded_bytes = 0
        self.download_start_time = 0
        self.download_last_update_bytes = 0
        self.download_last_update_time = 0
        self.download_current_speed = 0.0

        self.download_timer = eTimer()
        if self.download_timer:
            try:
                self.download_timer_conn = self.download_timer.timeout.connect(self.update_download_ui)
            except AttributeError:
                try:
                    self.download_timer.callback.append(self.update_download_ui)
                except Exception:
                    pass
        
        self.store_data = {}
        self.categories = []
        self.visible_items = []
        self.current_path = []
        self.active_focus = "categories"
        self.my_console = Console()
        
        self.install_cmd = ""
        self.install_item_name = ""
        
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back,
            "red": self.red_key_pressed,
            "green": self.download,
            "yellow": self.load_store,
            "blue": self.manual_update,
            "ok": self.press_ok,
            "up": self.go_up,
            "down": self.go_down,
            "left": self.switch_to_categories,
            "right": self.switch_to_items,
        }, -1)
        
        self["categories_list"].onSelectionChanged.append(self.category_changed)
        self["items_list"].onSelectionChanged.append(self.item_changed)
        
        self.load_local_cache()

        self.bg_sync_timer = eTimer()
        try:
            self.bg_sync_timer_conn = self.bg_sync_timer.timeout.connect(self.start_background_sync)
        except AttributeError:
            try:
                self.bg_sync_timer.callback.append(self.start_background_sync)
            except Exception:
                pass
        self.onLayoutFinish.append(self.schedule_bg_sync)

    def load_local_cache(self):
        try:
            if os.path.exists(CACHE_FILE):
                with open(CACHE_FILE, "r") as f:
                    cached_data = json.load(f)
                    if cached_data and "categories" in cached_data:
                        self.apply_store_data(cached_data)
                        return True
        except Exception:
            pass
        return False

    def schedule_bg_sync(self):
        if self.bg_sync_timer:
            self.bg_sync_timer.start(100, True)

    def start_background_sync(self):
        t = threading.Thread(target=self.async_network_fetch)
        t.daemon = True
        t.start()

    def async_network_fetch(self):
        try:
            current_ip = get_real_box_ip()
            self["sys_ip"].setText("IP: %s" % current_ip)
        except Exception:
            pass

        try:
            data = load_json_network(STORE_URL)
            if data and "categories" in data:
                self.apply_store_data(data)
                try:
                    with open(CACHE_FILE, "w") as f:
                        json.dump(data, f)
                except Exception:
                    pass
            elif not self.categories:
                self["description"].setText("Failed to connect to GitHub feed.")
        except Exception:
            pass

    def apply_store_data(self, data):
        try:
            store_title = "%s v%s" % (data.get("store_name", "M Store"), data.get("version", "1.3.2"))
            self.setTitle(store_title)
            
            self.store_data = data["categories"]
            if isinstance(self.store_data, dict):
                self.categories = list(self.store_data.keys())
            else:
                self.categories = []
            
            if "tools" not in self.categories:
                self.categories.append("tools")
            
            if self.categories:
                display_cats = []
                for cat in self.categories:
                    cat_clean_name = str(cat).replace("_", " ").capitalize()
                    
                    if cat == "tools":
                        remote_tools = self.store_data.get("tools", [])
                        count = len(BUILTIN_SYSTEM_TOOLS) + (len(remote_tools) if isinstance(remote_tools, list) else 0)
                    else:
                        cat_content = self.store_data.get(cat, [])
                        count = count_items_recursive(cat_content)
                    
                    if self.categories_list_has_multicontent:
                        display_cats.append((cat, cat_clean_name, count))
                    else:
                        display_cats.append("%s (%d)" % (cat_clean_name, count))
                        
                self["categories_list"].setList(display_cats)
                self.current_path = []
                self.category_changed()
        except Exception:
            pass

    def get_system_telemetry_info(self):
        info = {
            "device": "Box: Enigma2",
            "image": "OS: EGAMI",
            "cpu": "CPU: Normal",
            "temp": "Temp: --",
            "ram": "RAM: --",
            "flash": "Flash: --",
            "ip": "IP: --",
            "net": "Net: Online"
        }
        try:
            device_name = "Enigma2"
            image_name = "EGAMI"
            if os.path.exists("/proc/stb/info/model"):
                with open("/proc/stb/info/model", "r") as f:
                    device_name = f.read().strip().upper()
            elif os.path.exists("/proc/stb/info/boxtype"):
                with open("/proc/stb/info/boxtype", "r") as f:
                    device_name = f.read().strip().upper()

            if os.path.exists("/etc/image-version"):
                with open("/etc/image-version", "r") as f:
                    for line in f:
                        if "imagename" in line or "creator" in line or "name" in line:
                            val = line.split("=")[-1].strip().upper()
                            if val:
                                image_name = val
                                break
                                
            info["device"] = "Box: %s" % device_name
            info["image"] = "OS: %s" % image_name
        except Exception:
            pass

        try:
            temp_val = None
            for temp_path in ("/proc/stb/sensors/temp0/value", "/proc/stb/fp/temp_sensor", "/sys/class/thermal/thermal_zone0/temp"):
                if os.path.exists(temp_path):
                    with open(temp_path, "r") as f:
                        t_str = f.read().strip()
                        if t_str.isdigit():
                            t_num = int(t_str)
                            if t_num > 1000:
                                t_num = int(t_num / 1000)
                            temp_val = t_num
                            break
            info["temp"] = ("Temp: %d C" % temp_val) if temp_val is not None else "Temp: 42 C"

            if os.path.exists("/proc/loadavg"):
                with open("/proc/loadavg", "r") as f:
                    info["cpu"] = "CPU Load: %s" % f.read().split()[0]
            else:
                info["cpu"] = "CPU: Ready"
        except Exception:
            pass

        try:
            if os.path.exists("/proc/meminfo"):
                mem_total = 0
                mem_free = 0
                with open("/proc/meminfo", "r") as f:
                    for line in f:
                        parts = line.split(":")
                        if len(parts) >= 2:
                            k = parts[0].strip()
                            v = parts[1].strip().split()[0]
                            if k == "MemTotal":
                                mem_total = int(v)
                            elif k in ["MemFree", "MemAvailable"]:
                                mem_free = int(v)
                if mem_total > 0:
                    pct = int((float(mem_total - mem_free) / float(mem_total)) * 100)
                    info["ram"] = "RAM: %d%% (%dM Free)" % (pct, int(mem_free / 1024))

            stat = os.statvfs('/')
            free_gb = float(stat.f_bavail * stat.f_frsize) / (1024.0 * 1024.0 * 1024.0)
            info["flash"] = "Flash: %.1f GB Free" % free_gb
        except Exception:
            pass

        return info

    def build_category_entry(self, *args):
        try:
            category_id = "unknown"
            display_name = "Unknown"
            count = 0

            if len(args) == 1:
                arg0 = args[0]
                if isinstance(arg0, (list, tuple)):
                    if len(arg0) >= 1:
                        category_id = arg0[0]
                    if len(arg0) >= 2:
                        display_name = str(arg0[1])
                    if len(arg0) >= 3:
                        try:
                            count = int(arg0[2])
                        except Exception:
                            count = 0
                else:
                    category_id = str(arg0)
                    display_name = str(arg0)
            elif len(args) >= 2:
                category_id = args[0]
                display_name = str(args[1])
                if len(args) >= 3:
                    try:
                        count = int(args[2])
                    except Exception:
                        count = 0

            icon_path = get_category_icon_path(category_id)
            pixmap = None
            if icon_path and loadPNG:
                try:
                    pixmap = loadPNG(icon_path)
                except Exception:
                    pixmap = None

            res = [category_id]
            # Scaled sizes and coordinates for MultiContent
            icon_w = scale_x(70)
            icon_h = scale_y(70)
            icon_pos_x = scale_x(8)
            icon_pos_y = scale_y(5)
            row_h = scale_y(80)

            if pixmap and HAS_MULTICONTENT and MultiContentEntryPixmapAlphaTest:
                res.append(MultiContentEntryPixmapAlphaTest(pos=(icon_pos_x, icon_pos_y), size=(icon_w, icon_h), png=pixmap))
                text_x = scale_x(86)
                text_w = scale_x(200)
            else:
                text_x = scale_x(15)
                text_w = scale_x(270)

            if HAS_MULTICONTENT and MultiContentEntryText:
                res.append(MultiContentEntryText(pos=(text_x, 0), size=(text_w, row_h), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=str(display_name)))
                count_str = "[%d]" % int(count)
                res.append(MultiContentEntryText(pos=(scale_x(286), 0), size=(scale_x(74), row_h), font=0, flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text=count_str))
                
            return res
        except Exception:
            return [str(args[0]) if args else "Category"]

    def build_item_entry(self, *args):
        try:
            item = {}
            display_text = "Unknown"
            category_id = "unknown"

            if len(args) == 1:
                arg0 = args[0]
                if isinstance(arg0, (list, tuple)):
                    if len(arg0) >= 1:
                        item = arg0[0]
                    if len(arg0) >= 2:
                        display_text = str(arg0[1])
                    if len(arg0) >= 3:
                        category_id = str(arg0[2])
                else:
                    item = {"name": str(arg0)}
                    display_text = str(arg0)
            elif len(args) >= 2:
                item = args[0]
                display_text = str(args[1])
                if len(args) >= 3:
                    category_id = str(args[2])

            icon_path = get_item_icon_path(item, category_id)
            pixmap = None
            if icon_path and loadPNG:
                try:
                    pixmap = loadPNG(icon_path)
                except Exception:
                    pixmap = None

            res = [item]
            # Scaled sizes and coordinates for Item MultiContent
            icon_w = scale_x(56)
            icon_h = scale_y(56)
            icon_pos_x = scale_x(10)
            icon_pos_y = scale_y(10)
            row_h = scale_y(76)

            if pixmap and HAS_MULTICONTENT and MultiContentEntryPixmapAlphaTest:
                res.append(MultiContentEntryPixmapAlphaTest(pos=(icon_pos_x, icon_pos_y), size=(icon_w, icon_h), png=pixmap))
                text_x = scale_x(78)
                text_w = scale_x(670)
            else:
                text_x = scale_x(15)
                text_w = scale_x(740)

            if HAS_MULTICONTENT and MultiContentEntryText:
                res.append(MultiContentEntryText(pos=(text_x, 0), size=(text_w, row_h), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=str(display_text)))
                
            return res
        except Exception:
            return [str(args[0]) if args else "Item"]

    def load_store(self):
        self["description"].setText("Refreshing feed from GitHub...")
        t = threading.Thread(target=self.async_network_fetch)
        t.daemon = True
        t.start()

    def manual_update(self):
        self.session.openWithCallback(
            self.run_install_script,
            MessageBox,
            "Do you want to update Tarek-panel using online script?",
            MessageBox.TYPE_YESNO
        )

    def run_install_script(self, answer):
        if answer:
            self.start_script_update()
        else:
            self.load_store()

    def start_script_update(self):
        self.install_cmd = "chmod +x /tmp/install.sh && /tmp/install.sh && rm -f /tmp/install.sh"
        self.install_item_name = "Tarek-panel Update Script"
        self.download_url = "https://gitlab.com/hanfy1971/plugin/-/raw/main/MohamedStore-panel/tarek-panel.sh"
        self.download_dest_path = "/tmp/install.sh"
        self.download_is_update_script = True
        self.download_is_system_image = False
        self.download_is_picon = False
        self.download_aborted = False
        self.download_completed = False
        self.download_error_msg = ""
        self.download_total_bytes = 0
        self.downloaded_bytes = 0
        self.download_start_time = time.time()
        self.download_last_update_bytes = 0
        self.download_last_update_time = self.download_start_time
        self.download_current_speed = 0.0

        self["description"].setText("Downloading update script...\nPress RED or BACK to cancel.")
        self["key_red"].setText("Cancel")

        try:
            self["progress"].show()
            self["percentage"].show()
            self["speed"].show()
            self["size"].show()
            self["status"].show()

            self["progress"].setValue(0)
            self["percentage"].setText("0%")
            self["speed"].setText("0 KB/s")
            self["size"].setText("Downloading script...")
            self["status"].setText("Updating plugin...")
        except Exception:
            pass

        self.download_in_progress = True

        if self.download_timer:
            self.download_timer.start(100, False)

        self.download_thread_obj = threading.Thread(target=self.start_download_thread)
        self.download_thread_obj.daemon = True
        self.download_thread_obj.start()

    def update_finished(self, result, retval, extra_args=None):
        try:
            self["progress"].hide()
            self["percentage"].hide()
            self["speed"].hide()
            self["size"].hide()
            self["status"].hide()
        except Exception:
            pass
        self["key_red"].setText("Exit")

        if retval == 0:
            self.session.openWithCallback(
                self.restartGUICallback,
                MessageBox,
                "Tarek-panel updated successfully via script!\n\nRestart GUI now?",
                MessageBox.TYPE_YESNO
            )
        else:
            self["description"].setText("Self-Update Failed! Exit Code: " + str(retval))

    def restartGUICallback(self, answer):
        if answer:
            try:
                if TryQuitMainloop:
                    self.session.open(TryQuitMainloop, 3)
                else:
                    enigma.quitMainloop(3)
            except Exception:
                try:
                    enigma.quitMainloop(3)
                except Exception:
                    pass
        else:
            self.load_store()

    def category_changed(self):
        try:
            if self.active_focus == "categories":
                self.current_path = []
            
            idx = self["categories_list"].getSelectionIndex()
            if idx < 0 or idx >= len(self.categories):
                return
            
            selected_cat = self.categories[idx]
            if selected_cat == "tools":
                remote_tools = self.store_data.get("tools", [])
                self.visible_items = BUILTIN_SYSTEM_TOOLS + remote_tools
            else:
                category_data = self.store_data.get(selected_cat, [])
                if len(self.current_path) == 0:
                    self.visible_items = category_data
                else:
                    self.rebuild_visible_items()
            
            self.update_items_list()
        except Exception as e:
            self["description"].setText("Category Change Error: " + str(e))

    def rebuild_visible_items(self):
        try:
            idx = self["categories_list"].getSelectionIndex()
            if idx < 0 or idx >= len(self.categories):
                self.visible_items = []
                return
            
            selected_cat = self.categories[idx]
            if selected_cat == "tools":
                items = BUILTIN_SYSTEM_TOOLS + self.store_data.get("tools", [])
            else:
                items = self.store_data.get(selected_cat, [])
                
            for folder in self.current_path:
                items = folder.get("items", [])
            self.visible_items = items
        except Exception:
            self.visible_items = []

    def update_items_list(self):
        try:
            if not isinstance(self.visible_items, list):
                self["items_list"].setList([])
                self["description"].setText("No items found in this section.")
                return
            
            cat_idx = self["categories_list"].getSelectionIndex()
            category_id = self.categories[cat_idx] if (cat_idx >= 0 and cat_idx < len(self.categories)) else "unknown"

            display_items = []
            for item in self.visible_items:
                if "items" in item and isinstance(item["items"], list):
                    folder_count = count_items_recursive(item["items"])
                    display_text = "> %s  (%d)" % (str(item.get("name", "Unknown Folder")), folder_count)
                elif item.get("type") == "tool":
                    display_text = str(item.get("name", "Unknown Tool"))
                else:
                    ver = item.get("version")
                    if ver:
                        display_text = "%s  (v%s)" % (str(item.get("name", "Unknown")), str(ver))
                    else:
                        display_text = str(item.get("name", "Unknown"))

                if self.items_list_has_multicontent:
                    display_items.append((item, display_text, category_id))
                else:
                    display_items.append(display_text)
            
            self["items_list"].setList(display_items)
            self.item_changed()
        except Exception as e:
            self["description"].setText("Update Items List Error: " + str(e))

    def item_changed(self):
        try:
            idx = self["items_list"].getSelectionIndex()
            if idx < 0 or not self.visible_items or idx >= len(self.visible_items):
                return
            
            item = self.visible_items[idx]
            cat_idx = self["categories_list"].getSelectionIndex()
            cat_id = str(self.categories[cat_idx]).lower() if cat_idx >= 0 else ""
            cat_name = str(self.categories[cat_idx]).replace("_", " ").capitalize() if cat_idx >= 0 else "Unknown"
            
            path_parts = [cat_name]
            for folder in self.current_path:
                path_parts.append(str(folder.get("name", "")))
            path_str = " > ".join(path_parts)
            
            is_sys_img = ("image" in cat_id or "system" in cat_id or "neoboot" in cat_id or item.get("type") in ["image", "system_image", "system"])
            is_picon = ("picon" in cat_id or item.get("type") in ["picon", "picons"])
            
            if item.get("type") == "tool":
                self["key_green"].setText("Execute")
                info_text = "Section: %s\nTool Name: %s\n\nDescription:\n%s" % (
                    path_str,
                    str(item.get("name", "")),
                    str(item.get("description", "System tool execution."))
                )
            elif "items" in item and isinstance(item["items"], list):
                self["key_green"].setText("Install")
                sub_count = count_items_recursive(item["items"])
                info_text = "Section: %s\nFolder: %s (Packages: %d)\n\nPress OK to view packages inside this folder." % (
                    path_str,
                    str(item.get("name", "")),
                    sub_count
                )
            elif is_sys_img:
                self["key_green"].setText("Download")
                info_text = "Section: %s (NeoBoot Safe)\nImage: %s\nVersion: %s\n\nDescription:\n%s\n\n* Note: Downloaded directly as ZIP into NeoBoot ImagesUpload." % (
                    path_str,
                    str(item.get("name", "")),
                    str(item.get("version", "-")),
                    str(item.get("description", "Enigma2 System Image for NeoBoot."))
                )
            elif is_picon:
                self["key_green"].setText("Download")
                info_text = "Section: %s (Direct HDD ZIP)\nName: %s\nVersion: %s\n\nDescription:\n%s\n\n* Note: Downloaded directly into /media/hdd/." % (
                    path_str,
                    str(item.get("name", "")),
                    str(item.get("version", "-")),
                    str(item.get("description", "Channel Picons Package."))
                )
            else:
                self["key_green"].setText("Install")
                info_text = "Section: %s\nName: %s\nVersion: %s\n\nDescription:\n%s" % (
                    path_str,
                    str(item.get("name", "")),
                    str(item.get("version", "-")),
                    str(item.get("description", "No description available."))
                )
            self["description"].setText(info_text)
        except Exception as e:
            self["description"].setText("Item Change Error: " + str(e))

    def red_key_pressed(self):
        if self.download_in_progress:
            self.cancel_active_download()
        else:
            self.close()

    def switch_to_items(self):
        if self.download_in_progress:
            return
        if self.visible_items:
            self.active_focus = "items"
            self["description"].setText("Navigating: Items List\n\nPress OK or Green to Install / Execute.")

    def switch_to_categories(self):
        if self.download_in_progress:
            return
        if self.active_focus == "items" and len(self.current_path) > 0:
            self.current_path.pop()
            self.rebuild_visible_items()
            self.update_items_list()
        else:
            self.active_focus = "categories"
            self.current_path = []
            self.category_changed()

    def go_up(self):
        if self.download_in_progress:
            return
        try:
            if self.active_focus == "categories":
                self["categories_list"].up()
            else:
                self["items_list"].up()
        except Exception:
            pass

    def go_down(self):
        if self.download_in_progress:
            return
        try:
            if self.active_focus == "categories":
                self["categories_list"].down()
            else:
                self["items_list"].down()
        except Exception:
            pass

    def press_ok(self):
        if self.download_in_progress:
            return
        if self.active_focus == "categories":
            self.switch_to_items()
        else:
            idx = self["items_list"].getSelectionIndex()
            if idx >= 0 and idx < len(self.visible_items):
                item = self.visible_items[idx]
                if "items" in item and isinstance(item["items"], list):
                    self.current_path.append(item)
                    self.rebuild_visible_items()
                    self.update_items_list()
                else:
                    self.download()

    def go_back(self):
        if self.download_in_progress:
            self.cancel_active_download()
            return
        if self.active_focus == "items" and len(self.current_path) > 0:
            self.current_path.pop()
            self.rebuild_visible_items()
            self.update_items_list()
        elif self.active_focus == "items" and len(self.current_path) == 0:
            self.switch_to_categories()
        else:
            self.close()

    def download(self):
        if self.download_in_progress:
            return
        try:
            idx = self["items_list"].getSelectionIndex()
            if idx >= 0 and idx < len(self.visible_items) and self.visible_items:
                item = self.visible_items[idx]
                
                if item.get("type") == "tool":
                    action = item.get("action", "")
                    if action == "check_oscam_status":
                        success, msg = get_active_oscam_status()
                        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
                        self.item_changed()
                        return

                    elif action == "tiger_server":
                        self["description"].setText("Activating Free 24h Server...\nDisabling Paid Server...\nPlease wait...")
                        def _run_tiger():
                            success, msg = generate_tigerhd_server()
                            def _show_res():
                                if success:
                                    self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
                                else:
                                    self.session.open(MessageBox, "Failed to activate server:\n" + msg, MessageBox.TYPE_ERROR)
                                self.item_changed()
                            if sys.version_info >= (3, 0):
                                try:
                                    from twisted.internet import reactor
                                    reactor.callFromThread(_show_res)
                                except Exception:
                                    _show_res()
                            else:
                                _show_res()
                        
                        t = threading.Thread(target=_run_tiger)
                        t.daemon = True
                        t.start()
                        return

                    elif action == "restore_paid":
                        success, msg = restore_paid_oscam()
                        if success:
                            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
                        else:
                            self.session.open(MessageBox, msg, MessageBox.TYPE_WARNING)
                        self.item_changed()
                        return

                    elif action == "restart_oscam":
                        success, msg = restart_oscam_service()
                        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
                        self.item_changed()
                        return

                    elif action == "stop_oscam":
                        success, msg = stop_oscam_service()
                        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO)
                        self.item_changed()
                        return

                    elif action == "uninstaller":
                        self.session.open(Uninstaller)
                        return

                    elif action == "football_matches":
                        self.session.open(FootballMatches)
                        return

                    elif action == "weather":
                        self.session.open(WeatherScreen)
                        return

                    elif action == "iptv":
                        self.session.open(IPTVScreen)
                        return

                    elif action == "kingofsat":
                        self.session.open(KingOfSatScreen)
                        return

                    elif action == "news":
                        self.session.open(NewsScreen)
                        return

                    cmd = item.get("cmd", "")
                    if cmd == "restart_gui":
                        if TryQuitMainloop:
                            self.session.open(TryQuitMainloop, 3)
                        else:
                            enigma.quitMainloop(3)
                    elif cmd:
                        self["description"].setText("Executing tool: %s\nPlease wait..." % item.get("name", ""))
                        self.my_console.ePopen(cmd + " 2>&1", self.tool_execution_finished)
                    return

                if "items" in item and isinstance(item["items"], list):
                    self.current_path.append(item)
                    self.rebuild_visible_items()
                    self.update_items_list()
                    return
                
                url = item.get("file", "").strip()
                if not url:
                    self["description"].setText("Error: Download URL is missing in JSON.")
                    return
                
                pure_url = url.split('?')[0]
                ext = ""
                if pure_url.endswith(".tar.gz"):
                    ext = ".tar.gz"
                else:
                    _, ext_part = os.path.splitext(pure_url)
                    ext = ext_part.lower()

                filename = pure_url.split('/')[-1]
                if not filename:
                    filename = "addon" + ext

                cat_idx = self["categories_list"].getSelectionIndex()
                cat_id = str(self.categories[cat_idx]).lower() if cat_idx >= 0 else ""
                item_type = str(item.get("type", "")).lower()
                
                is_system_image = ("system" in cat_id or "image" in cat_id or "neoboot" in cat_id or item_type in ["image", "system", "system_image"])
                is_picon = ("picon" in cat_id or item_type in ["picon", "picons"])

                dest_path = ""
                cmd = ""

                if is_system_image:
                    target_dir = get_neoboot_images_upload_path()
                    safe_filename = filename if filename.lower().endswith(".zip") else (filename + ".zip")
                    dest_path = os.path.join(target_dir, safe_filename)
                    cmd = "sync"
                    self.download_is_system_image = True
                    self.download_is_picon = False

                elif is_picon:
                    target_dir = get_direct_hdd_root_path()
                    safe_filename = filename if filename.lower().endswith(".zip") else (filename + ".zip")
                    dest_path = os.path.join(target_dir, safe_filename)
                    cmd = "sync"
                    self.download_is_system_image = False
                    self.download_is_picon = True

                else:
                    self.download_is_system_image = False
                    self.download_is_picon = False
                    if ext == ".deb":
                        dest_path = "/tmp/addon.deb"
                        cmd = "dpkg -i /tmp/addon.deb && rm -f /tmp/addon.deb"
                    elif ext == ".ipk":
                        dest_path = "/tmp/addon.ipk"
                        cmd = "opkg install --force-overwrite /tmp/addon.ipk && rm -f /tmp/addon.ipk"
                    elif ext == ".sh":
                        dest_path = "/tmp/addon.sh"
                        cmd = "chmod +x /tmp/addon.sh && /tmp/addon.sh && rm -f /tmp/addon.sh"
                    elif ext == ".zip":
                        dest_path = "/tmp/addon.zip"
                        cmd = "unzip -o /tmp/addon.zip -d / && rm -f /tmp/addon.zip"
                    elif ext in [".tar.gz", ".tgz"]:
                        dest_path = "/tmp/addon.tar.gz"
                        cmd = "tar -xzf /tmp/addon.tar.gz -C / && rm -f /tmp/addon.tar.gz"
                    elif ext == ".tar":
                        dest_path = "/tmp/addon.tar"
                        cmd = "tar -xf /tmp/addon.tar -C / && rm -f /tmp/addon.tar"
                    elif ext == ".tv":
                        dest_path = os.path.join("/etc/enigma2", filename)
                        cmd = (
                            "if ! grep -q '" + filename + "' /etc/enigma2/bouquets.tv; then "
                            "echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"" + filename + "\" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv; "
                            "fi && "
                            "(wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 || "
                            "curl -s http://127.0.0.1/web/servicelistreload?mode=0 || true)"
                        )
                    elif ext == ".py":
                        dest_path = "/tmp/addon.py"
                        cmd = "(python /tmp/addon.py || python3 /tmp/addon.py) && rm -f /tmp/addon.py"
                    else:
                        dest_path = "/tmp/addon.ipk"
                        cmd = "opkg install --force-overwrite /tmp/addon.ipk && rm -f /tmp/addon.ipk"

                self.install_cmd = cmd
                self.install_item_name = str(item.get("name", ""))
                self.download_url = url
                self.download_dest_path = dest_path
                self.download_is_update_script = False
                self.download_aborted = False
                self.download_completed = False
                self.download_error_msg = ""
                self.download_total_bytes = 0
                self.downloaded_bytes = 0
                self.download_start_time = time.time()
                self.download_last_update_bytes = 0
                self.download_last_update_time = self.download_start_time
                self.download_current_speed = 0.0
                
                self["description"].setText("Downloading: %s\n\nPress RED or BACK to cancel." % self.install_item_name)
                self["key_red"].setText("Cancel")
                
                try:
                    self["progress"].show()
                    self["percentage"].show()
                    self["speed"].show()
                    self["size"].show()
                    self["status"].show()
                    
                    self["progress"].setValue(0)
                    self["percentage"].setText("0%")
                    self["speed"].setText("0 KB/s")
                    self["size"].setText("0 MB / 0 MB")
                    self["status"].setText(os.path.basename(dest_path))
                except Exception:
                    pass
                
                self.download_in_progress = True
                if self.download_timer:
                    self.download_timer.start(100, False)
                    
                self.download_thread_obj = threading.Thread(target=self.start_download_thread)
                self.download_thread_obj.daemon = True
                self.download_thread_obj.start()
                
        except Exception:
            self["description"].setText("Execution error, check system log.")

    def tool_execution_finished(self, result, retval, extra_args=None):
        if retval == 0:
            self.session.open(MessageBox, "Tool executed successfully!", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Tool execution failed!", MessageBox.TYPE_ERROR)
        self.item_changed()

    def start_download_thread(self):
        try:
            if sys.version_info >= (3, 0):
                import urllib.request as urllib2
                import ssl
                context = ssl._create_unverified_context()
            else:
                import urllib2
                import ssl
                try:
                    context = ssl._create_unverified_context()
                except AttributeError:
                    context = None
                    
            url = self.download_url
            try:
                if sys.version_info >= (3, 0):
                    from urllib.parse import quote as urllib_quote
                    url = str(url)
                else:
                    from urllib import quote as urllib_quote
                    if isinstance(url, unicode):
                        url = url.encode('utf-8')
                url = urllib_quote(url, safe='/:?=&%')
            except Exception:
                url = url.replace(" ", "%20")
                
            req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            opener = urllib2.build_opener(urllib2.HTTPSHandler(context=context)) if context else urllib2.build_opener()
            response = opener.open(req, timeout=12)
                
            try:
                self.download_total_bytes = int(response.info().get('Content-Length', 0))
            except Exception:
                self.download_total_bytes = 0
                
            dir_name = os.path.dirname(self.download_dest_path)
            if dir_name and not os.path.exists(dir_name):
                try:
                    os.makedirs(dir_name)
                except Exception:
                    pass
                
            self.download_start_time = time.time()
            self.download_last_update_time = self.download_start_time
            self.download_last_update_bytes = 0
            
            with open(self.download_dest_path, 'wb') as f:
                while not self.download_aborted:
                    chunk = response.read(16384)
                    if not chunk:
                        break
                    f.write(chunk)
                    self.downloaded_bytes += len(chunk)
                    
            if self.download_aborted:
                if os.path.exists(self.download_dest_path):
                    try:
                        os.remove(self.download_dest_path)
                    except Exception:
                        pass
            else:
                self.download_completed = True
        except Exception as e:
            self.download_error_msg = str(e)
            if os.path.exists(self.download_dest_path):
                try:
                    os.remove(self.download_dest_path)
                except Exception:
                    pass

    def update_download_ui(self):
        if not self.download_in_progress:
            return
            
        now = time.time()
        elapsed = now - self.download_last_update_time
        if elapsed >= 0.5:
            diff_bytes = self.downloaded_bytes - self.download_last_update_bytes
            self.download_current_speed = float(diff_bytes) / elapsed
            self.download_last_update_bytes = self.downloaded_bytes
            self.download_last_update_time = now
            
        if self.download_total_bytes > 0:
            pct = int(float(self.downloaded_bytes) / self.download_total_bytes * 100)
            pct = min(100, max(0, pct))
            if ProgressBar:
                try:
                    self["progress"].setValue(pct)
                except Exception:
                    pass
            self["percentage"].setText("%d%%" % pct)
            
            dl_mb = float(self.downloaded_bytes) / (1024 * 1024)
            tot_mb = float(self.download_total_bytes) / (1024 * 1024)
            self["size"].setText("%.2f MB / %.2f MB" % (dl_mb, tot_mb))
        else:
            if ProgressBar:
                try:
                    self["progress"].setValue(0)
                except Exception:
                    pass
            self["percentage"].setText("---")
            dl_kb = float(self.downloaded_bytes) / 1024
            self["size"].setText("%.1f KB / Unknown" % dl_kb)
            
        if self.download_current_speed > 1024 * 1024:
            speed_str = "%.2f MB/s" % (self.download_current_speed / (1024 * 1024))
        else:
            speed_str = "%.1f KB/s" % (self.download_current_speed / 1024)
        self["speed"].setText(speed_str)
        
        if self.download_completed:
            self.download_in_progress = False
            if self.download_timer:
                self.download_timer.stop()
            
            if self.download_is_update_script:
                self.download_is_update_script = False
                self["description"].setText("Executing Tarek-panel Update Script...\nPlease wait...")
                try:
                    self["progress"].setValue(100)
                    self["percentage"].setText("100%")
                    self["status"].setText("Executing install.sh...")
                except Exception:
                    pass
                self.my_console.ePopen(self.install_cmd + " 2>&1", self.update_finished)

            elif self.download_is_system_image:
                self.download_is_system_image = False
                try:
                    self["progress"].hide()
                    self["percentage"].hide()
                    self["speed"].hide()
                    self["size"].hide()
                    self["status"].hide()
                except Exception:
                    pass
                    
                self["key_red"].setText("Exit")
                file_size_mb = float(self.downloaded_bytes) / (1024.0 * 1024.0)
                success_msg = u"Image downloaded successfully as a ZIP file!\n\nSize: %.1f MB\nPath: %s\n\nYou can now open NeoBoot and install it." % (file_size_mb, str(self.download_dest_path))
                self["description"].setText(success_msg)
                self.session.open(MessageBox, success_msg, MessageBox.TYPE_INFO)
                self.item_changed()

            elif self.download_is_picon:
                self.download_is_picon = False
                try:
                    self["progress"].hide()
                    self["percentage"].hide()
                    self["speed"].hide()
                    self["size"].hide()
                    self["status"].hide()
                except Exception:
                    pass
                    
                self["key_red"].setText("Exit")
                file_size_mb = float(self.downloaded_bytes) / (1024.0 * 1024.0)
                success_msg = u"Picons ZIP package downloaded directly to HDD!\n\nSize: %.1f MB\nPath: %s" % (file_size_mb, str(self.download_dest_path))
                self["description"].setText(success_msg)
                self.session.open(MessageBox, success_msg, MessageBox.TYPE_INFO)
                self.item_changed()

            else:
                try:
                    self["progress"].hide()
                    self["percentage"].hide()
                    self["speed"].hide()
                    self["size"].hide()
                    self["status"].hide()
                except Exception:
                    pass
                    
                self["key_red"].setText("Exit")
                self["description"].setText("Download completed successfully!")
                
                self.session.openWithCallback(
                    self.install_confirmation_callback,
                    MessageBox,
                    "Download completed successfully.\n\nDo you want to install it now?",
                    MessageBox.TYPE_YESNO
                )
            
        elif self.download_error_msg:
            self.download_in_progress = False
            if self.download_timer:
                self.download_timer.stop()
                
            try:
                self["progress"].hide()
                self["percentage"].hide()
                self["speed"].hide()
                self["size"].hide()
                self["status"].hide()
            except Exception:
                pass
                
            self["key_red"].setText("Exit")
            self["description"].setText("Download failed: " + self.download_error_msg)

    def cancel_active_download(self):
        self.download_aborted = True
        self.download_in_progress = False
        if self.download_timer:
            self.download_timer.stop()
        
        try:
            self["progress"].hide()
            self["percentage"].hide()
            self["speed"].hide()
            self["size"].hide()
            self["status"].hide()
        except Exception:
            pass
            
        self["key_red"].setText("Exit")
        self["description"].setText("Download cancelled by user.")
        
        if self.download_dest_path and os.path.exists(self.download_dest_path):
            try:
                os.remove(self.download_dest_path)
            except Exception:
                pass

    def install_confirmation_callback(self, answer):
        if answer:
            self["description"].setText("Installing %s...\nPlease wait..." % self.install_item_name)
            self.my_console.ePopen(self.install_cmd + " 2>&1", self.download_finished)
        else:
            self["description"].setText("Installation skipped.")
            self.item_changed()

    def download_finished(self, result, retval, extra_args=None):
        if retval == 0:
            self.session.openWithCallback(self.restartCallback, MessageBox, "Installation completed successfully!\n\nRestart GUI now?", MessageBox.TYPE_YESNO)
        else:
            error = result.strip() if result else "Unknown error"
            self["description"].setText("Installation Failed!\n\nExit Code: " + str(retval) + "\n\n" + str(error))

    def restartCallback(self, answer):
        if answer:
            try:
                if TryQuitMainloop:
                    self.session.open(TryQuitMainloop, 3)
                else:
                    enigma.quitMainloop(3)
            except Exception:
                try:
                    enigma.quitMainloop(3)
                except Exception:
                    pass
        else:
            self["description"].setText("Installation completed successfully. Restart skipped.")

def main(session, **kwargs):
    session.open(MohamedStore)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Tarek-panel",
            description="Download and install addons, plugins, and softcams",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]
